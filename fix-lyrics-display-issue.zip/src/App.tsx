import { useState, useEffect, useRef } from "react";

const ALBUM_ART =
  "https://images.pexels.com/photos/16844652/pexels-photo-16844652.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=600&w=600";

const lyrics = [
  { time: 0,   text: "Khat likhu tere liye" },
  { time: 8,   text: "Neele phool laau tere liye" },
  { time: 16,  text: "Pasand hai tumhe, maloom hai" },
  { time: 24,  text: "Tumne bataya tha ek dafe" },
  { time: 32,  text: "Neele phool laau tere liye" },
  { time: 40,  text: "Khat likhu tere liye" },
  { time: 48,  text: "Mai khuda me maanu nahi" },
  { time: 56,  text: "Pasand hai tumhe, maloom hai" },
  { time: 64,  text: "Tumne bataya tha ek dafe" },
  { time: 72,  text: "Khat likhu tere liye" },
  { time: 80,  text: "Teri aankhon ki baat karu" },
  { time: 88,  text: "Neele phool laau tere liye" },
  { time: 96,  text: "Khat likhu tere liye" },
  { time: 104, text: "Mai khuda me maanu nahi" },
  { time: 112, text: "Pasand hai tumhe, maloom hai" },
  { time: 120, text: "Tumne bataya tha ek dafe" },
  { time: 128, text: "Neele phool laau tere liye" },
  { time: 136, text: "Khat likhu tere liye" },
  { time: 144, text: "Khat likhu tere liye..." },
];

const SONG_DURATION = 240; // 4:00

function formatTime(seconds: number) {
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

export default function App() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(56); // start at 0:56 like screenshot
  const [volume, setVolume] = useState(70);
  const [isStarred, setIsStarred] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const lyricsRef = useRef<HTMLDivElement>(null);

  // Find current lyric index
  const currentLyricIndex = lyrics.reduce((acc, lyric, idx) => {
    if (currentTime >= lyric.time) return idx;
    return acc;
  }, 0);

  useEffect(() => {
    if (isPlaying) {
      intervalRef.current = setInterval(() => {
        setCurrentTime((t) => {
          if (t >= SONG_DURATION) {
            setIsPlaying(false);
            return 0;
          }
          return t + 0.5;
        });
      }, 500);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isPlaying]);

  // Scroll lyrics into view
  useEffect(() => {
    if (lyricsRef.current) {
      const activeLine = lyricsRef.current.querySelector(".lyric-active");
      if (activeLine) {
        activeLine.scrollIntoView({ behavior: "smooth", block: "center" });
      }
    }
  }, [currentLyricIndex]);

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    setCurrentTime(Number(e.target.value));
  };

  const handleSkipBack = () => setCurrentTime((t) => Math.max(0, t - 10));
  const handleSkipForward = () => setCurrentTime((t) => Math.min(SONG_DURATION, t + 10));

  const remaining = SONG_DURATION - currentTime;

  return (
    <div
      className="relative flex items-center justify-center w-full min-h-screen overflow-hidden"
      style={{
        background: "linear-gradient(135deg, #0f1729 0%, #1a1f3a 30%, #2d1f4a 60%, #1a1630 100%)",
      }}
    >
      {/* Background blur blob */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 60% 50% at 70% 50%, rgba(80,40,140,0.35) 0%, transparent 70%), radial-gradient(ellipse 40% 60% at 20% 60%, rgba(30,50,120,0.25) 0%, transparent 70%)",
        }}
      />

      {/* Vinyl disc hint bottom left */}
      <div className="absolute bottom-6 left-6 z-10">
        <div
          className="w-16 h-16 rounded-full flex items-center justify-center"
          style={{
            background: "radial-gradient(circle, #444 30%, #222 60%, #111 100%)",
            boxShadow: "0 0 0 3px #333, 0 0 0 5px #222",
            animation: isPlaying ? "spin 4s linear infinite" : "none",
          }}
        >
          <div className="w-4 h-4 rounded-full bg-gray-500" />
        </div>
      </div>

      {/* "lyric metro" watermark bottom right */}
      <div className="absolute bottom-6 right-6 z-10 text-xs text-gray-500 tracking-widest opacity-60">
        lyric metro
      </div>

      {/* Main layout */}
      <div className="relative z-10 flex flex-col lg:flex-row items-center lg:items-stretch gap-8 lg:gap-16 px-8 w-full max-w-5xl">
        {/* Left: Player Card */}
        <div className="flex-shrink-0 w-full max-w-xs lg:max-w-sm">
          {/* Album art with label */}
          <div
            className="relative rounded-2xl overflow-hidden shadow-2xl mb-4"
            style={{
              boxShadow: "0 8px 40px rgba(0,0,0,0.6)",
              border: "1px solid rgba(255,255,255,0.08)",
            }}
          >
            {/* KHAT label */}
            <div className="absolute top-0 left-0 z-10 px-3 py-2">
              <div className="text-white font-bold text-base tracking-widest leading-none">KHAT</div>
              <div className="text-gray-300 text-xs tracking-wider mt-0.5">ख़त | خط</div>
            </div>
            <img
              src={ALBUM_ART}
              alt="Khat - Navjot Ahuja"
              className="w-full object-cover"
              style={{ height: "360px", filter: "brightness(0.75) saturate(1.1)" }}
            />
            {/* Blue overlay tint */}
            <div
              className="absolute inset-0"
              style={{
                background:
                  "linear-gradient(180deg, rgba(10,20,60,0.3) 0%, transparent 40%, rgba(10,20,60,0.5) 100%)",
              }}
            />
          </div>

          {/* Song info + star + menu */}
          <div className="flex items-center justify-between mb-3 px-1">
            <div>
              <div className="text-white font-semibold text-base leading-tight">Khat</div>
              <div className="text-gray-400 text-sm">Navjot Ahuja — Khat - Single</div>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setIsStarred(!isStarred)}
                className="text-gray-400 hover:text-yellow-300 transition-colors"
              >
                <svg
                  viewBox="0 0 24 24"
                  className="w-5 h-5"
                  fill={isStarred ? "currentColor" : "none"}
                  stroke="currentColor"
                  strokeWidth={2}
                >
                  <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
                </svg>
              </button>
              <div className="relative">
                <button
                  onClick={() => setShowMenu(!showMenu)}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor">
                    <circle cx="12" cy="5" r="1.5" />
                    <circle cx="12" cy="12" r="1.5" />
                    <circle cx="12" cy="19" r="1.5" />
                  </svg>
                </button>
                {showMenu && (
                  <div
                    className="absolute right-0 top-7 z-30 rounded-xl py-1 w-44 text-sm shadow-xl"
                    style={{ background: "#2a2a3e", border: "1px solid rgba(255,255,255,0.1)" }}
                  >
                    {["Add to playlist", "Share song", "Go to artist", "Song info"].map((item) => (
                      <button
                        key={item}
                        className="w-full text-left px-4 py-2 text-gray-300 hover:text-white hover:bg-white/10 transition-colors"
                        onClick={() => setShowMenu(false)}
                      >
                        {item}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Progress bar */}
          <div className="px-1 mb-3">
            <div className="relative mb-1">
              <input
                type="range"
                min={0}
                max={SONG_DURATION}
                step={0.5}
                value={currentTime}
                onChange={handleSeek}
                className="w-full h-1 rounded-full appearance-none cursor-pointer"
                style={{
                  background: `linear-gradient(to right, #ffffff ${(currentTime / SONG_DURATION) * 100}%, rgba(255,255,255,0.2) ${(currentTime / SONG_DURATION) * 100}%)`,
                  accentColor: "#ffffff",
                }}
              />
            </div>
            <div className="flex justify-between text-xs text-gray-400">
              <span>{formatTime(currentTime)}</span>
              <span>-{formatTime(remaining)}</span>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center gap-6 mb-4">
            {/* Shuffle */}
            <button className="text-gray-400 hover:text-white transition-colors">
              <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={2}>
                <polyline points="16 3 21 3 21 8" />
                <line x1="4" y1="20" x2="21" y2="3" />
                <polyline points="21 16 21 21 16 21" />
                <line x1="4" y1="4" x2="9" y2="9" />
              </svg>
            </button>
            {/* Skip back */}
            <button
              onClick={handleSkipBack}
              className="text-white hover:text-gray-300 transition-colors"
            >
              <svg viewBox="0 0 24 24" className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth={2}>
                <polygon points="19 20 9 12 19 4 19 20" />
                <line x1="5" y1="19" x2="5" y2="5" />
              </svg>
            </button>
            {/* Play/Pause */}
            <button
              onClick={() => setIsPlaying(!isPlaying)}
              className="w-12 h-12 rounded-full flex items-center justify-center text-black transition-all hover:scale-105"
              style={{ background: "white", boxShadow: "0 4px 15px rgba(255,255,255,0.3)" }}
            >
              {isPlaying ? (
                <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor">
                  <rect x="6" y="4" width="4" height="16" />
                  <rect x="14" y="4" width="4" height="16" />
                </svg>
              ) : (
                <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor">
                  <polygon points="5 3 19 12 5 21 5 3" />
                </svg>
              )}
            </button>
            {/* Skip forward */}
            <button
              onClick={handleSkipForward}
              className="text-white hover:text-gray-300 transition-colors"
            >
              <svg viewBox="0 0 24 24" className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth={2}>
                <polygon points="5 4 15 12 5 20 5 4" />
                <line x1="19" y1="5" x2="19" y2="19" />
              </svg>
            </button>
            {/* Repeat */}
            <button className="text-gray-400 hover:text-white transition-colors">
              <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth={2}>
                <polyline points="17 1 21 5 17 9" />
                <path d="M3 11V9a4 4 0 0 1 4-4h14" />
                <polyline points="7 23 3 19 7 15" />
                <path d="M21 13v2a4 4 0 0 1-4 4H3" />
              </svg>
            </button>
          </div>

          {/* Volume */}
          <div className="flex items-center gap-2 px-1">
            <svg viewBox="0 0 24 24" className="w-4 h-4 text-gray-400 flex-shrink-0" fill="none" stroke="currentColor" strokeWidth={2}>
              <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
            </svg>
            <input
              type="range"
              min={0}
              max={100}
              value={volume}
              onChange={(e) => setVolume(Number(e.target.value))}
              className="flex-1 h-1 rounded-full appearance-none cursor-pointer"
              style={{
                background: `linear-gradient(to right, #ffffff ${volume}%, rgba(255,255,255,0.2) ${volume}%)`,
                accentColor: "#ffffff",
              }}
            />
          </div>
        </div>

        {/* Right: Lyrics panel */}
        <div className="flex-1 flex items-center overflow-hidden" style={{ minHeight: "420px", maxHeight: "520px" }}>
          <div
            ref={lyricsRef}
            className="w-full h-full overflow-y-auto pr-2 flex flex-col justify-center gap-2"
            style={{
              scrollbarWidth: "none",
              msOverflowStyle: "none",
              maskImage: "linear-gradient(to bottom, transparent 0%, black 15%, black 85%, transparent 100%)",
              WebkitMaskImage: "linear-gradient(to bottom, transparent 0%, black 15%, black 85%, transparent 100%)",
            }}
          >
            {/* Spacer top */}
            <div style={{ height: "120px", flexShrink: 0 }} />
            {lyrics.map((lyric, idx) => {
              const isActive = idx === currentLyricIndex;

              const distance = Math.abs(idx - currentLyricIndex);

              let opacity = 1;
              let fontSize = "1.1rem";
              let fontWeight = "400";
              let color = "#6b7280"; // gray-500

              if (isActive) {
                opacity = 1;
                fontSize = "2rem";
                fontWeight = "700";
                color = "#ffffff";
              } else if (distance === 1) {
                opacity = 0.65;
                fontSize = "1.4rem";
                fontWeight = "500";
                color = "#9ca3af";
              } else if (distance === 2) {
                opacity = 0.45;
                fontSize = "1.15rem";
                fontWeight = "400";
                color = "#6b7280";
              } else {
                opacity = 0.25;
                fontSize = "1rem";
                color = "#4b5563";
              }

              return (
                <div
                  key={idx}
                  className={`transition-all duration-700 cursor-pointer select-none leading-snug ${isActive ? "lyric-active" : ""}`}
                  style={{
                    opacity,
                    fontSize,
                    fontWeight,
                    color,
                    lineHeight: 1.4,
                    paddingTop: isActive ? "0.5rem" : "0.2rem",
                    paddingBottom: isActive ? "0.5rem" : "0.2rem",
                  }}
                  onClick={() => setCurrentTime(lyric.time)}
                >
                  {lyric.text}
                </div>
              );
            })}
            {/* Spacer bottom */}
            <div style={{ height: "120px", flexShrink: 0 }} />
          </div>
        </div>
      </div>

      {/* CSS for spin animation */}
      <style>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        input[type=range]::-webkit-slider-thumb {
          -webkit-appearance: none;
          width: 12px;
          height: 12px;
          border-radius: 50%;
          background: white;
          cursor: pointer;
        }
        input[type=range]::-moz-range-thumb {
          width: 12px;
          height: 12px;
          border-radius: 50%;
          background: white;
          cursor: pointer;
          border: none;
        }
        ::-webkit-scrollbar { display: none; }
      `}</style>
    </div>
  );
}
