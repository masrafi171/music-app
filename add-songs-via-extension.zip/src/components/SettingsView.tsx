import { Volume2, Repeat, Shuffle, ExternalLink, Info, Music } from 'lucide-react';
import { useMusicStore } from '../store/musicStore';

export default function SettingsView() {
  const {
    volume, setVolume,
    isMuted, toggleMute,
    isShuffled, toggleShuffle,
    repeatMode, toggleRepeat,
    playlist,
  } = useMusicStore();

  return (
    <div className="flex-1 overflow-y-auto">
      <div className="max-w-2xl mx-auto p-5 md:p-8 space-y-6">
        <div>
          <h1 className="text-white font-bold text-2xl mb-1">Settings</h1>
          <p className="text-white/40 text-sm">Customize your Echo TV experience</p>
        </div>

        {/* Playback */}
        <div className="bg-white/5 rounded-2xl border border-white/10 overflow-hidden">
          <div className="px-5 py-4 border-b border-white/10">
            <h2 className="text-white font-semibold text-sm">Playback</h2>
          </div>
          <div className="divide-y divide-white/5">
            {/* Volume */}
            <div className="px-5 py-4 flex items-center gap-4">
              <div className="w-9 h-9 rounded-xl bg-violet-500/20 flex items-center justify-center shrink-0">
                <Volume2 className="w-4.5 h-4.5 text-violet-400" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-white text-sm font-medium">Volume</p>
                <p className="text-white/40 text-xs">{isMuted ? 'Muted' : `${volume}%`}</p>
              </div>
              <div className="flex items-center gap-3">
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={isMuted ? 0 : volume}
                  onChange={(e) => setVolume(Number(e.target.value))}
                  className="w-28 accent-violet-500"
                />
                <button
                  onClick={toggleMute}
                  className={`text-xs px-2.5 py-1 rounded-lg font-medium transition-colors ${
                    isMuted ? 'bg-red-500/20 text-red-400' : 'bg-white/10 text-white/60'
                  }`}
                >
                  {isMuted ? 'Unmute' : 'Mute'}
                </button>
              </div>
            </div>

            {/* Shuffle */}
            <div className="px-5 py-4 flex items-center gap-4">
              <div className="w-9 h-9 rounded-xl bg-violet-500/20 flex items-center justify-center shrink-0">
                <Shuffle className="w-4.5 h-4.5 text-violet-400" />
              </div>
              <div className="flex-1">
                <p className="text-white text-sm font-medium">Shuffle</p>
                <p className="text-white/40 text-xs">Play songs in random order</p>
              </div>
              <button
                onClick={toggleShuffle}
                className={`relative w-11 h-6 rounded-full transition-colors ${
                  isShuffled ? 'bg-violet-500' : 'bg-white/20'
                }`}
              >
                <span
                  className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${
                    isShuffled ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Repeat */}
            <div className="px-5 py-4 flex items-center gap-4">
              <div className="w-9 h-9 rounded-xl bg-violet-500/20 flex items-center justify-center shrink-0">
                <Repeat className="w-4.5 h-4.5 text-violet-400" />
              </div>
              <div className="flex-1">
                <p className="text-white text-sm font-medium">Repeat</p>
                <p className="text-white/40 text-xs capitalize">
                  {repeatMode === 'none' ? 'No repeat' : repeatMode === 'one' ? 'Repeat current song' : 'Repeat all songs'}
                </p>
              </div>
              <button
                onClick={toggleRepeat}
                className={`text-xs px-3 py-1.5 rounded-lg font-medium capitalize transition-colors ${
                  repeatMode !== 'none'
                    ? 'bg-violet-500/20 text-violet-300 border border-violet-500/30'
                    : 'bg-white/10 text-white/60'
                }`}
              >
                {repeatMode === 'none' ? 'Off' : repeatMode === 'one' ? 'One' : 'All'}
              </button>
            </div>
          </div>
        </div>

        {/* Library */}
        <div className="bg-white/5 rounded-2xl border border-white/10 overflow-hidden">
          <div className="px-5 py-4 border-b border-white/10">
            <h2 className="text-white font-semibold text-sm">Library</h2>
          </div>
          <div className="px-5 py-4 flex items-center gap-4">
            <div className="w-9 h-9 rounded-xl bg-violet-500/20 flex items-center justify-center shrink-0">
              <Music className="w-4.5 h-4.5 text-violet-400" />
            </div>
            <div className="flex-1">
              <p className="text-white text-sm font-medium">Songs in Playlist</p>
              <p className="text-white/40 text-xs">{playlist.length} songs loaded</p>
            </div>
          </div>
        </div>

        {/* YouTube Extension */}
        <div className="bg-white/5 rounded-2xl border border-white/10 overflow-hidden">
          <div className="px-5 py-4 border-b border-white/10">
            <h2 className="text-white font-semibold text-sm">YouTube Extension</h2>
          </div>
          <div className="px-5 py-4 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              <p className="text-white/70 text-sm">Connected & active</p>
            </div>
            <div className="space-y-2 text-sm text-white/50">
              <p>This player uses the YouTube IFrame API and noembed.com to load song metadata, powered by the Echo YouTube Extension concept.</p>
            </div>
            <a
              href="https://github.com/brahmkshatriya/echo-youtube-extension-old"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-violet-400 hover:text-violet-300 text-sm transition-colors"
            >
              <ExternalLink className="w-4 h-4" />
              View Extension on GitHub
            </a>
          </div>
        </div>

        {/* About */}
        <div className="bg-white/5 rounded-2xl border border-white/10 overflow-hidden">
          <div className="px-5 py-4 border-b border-white/10">
            <h2 className="text-white font-semibold text-sm">About</h2>
          </div>
          <div className="px-5 py-4 flex items-start gap-4">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-500 to-pink-500 flex items-center justify-center shrink-0 shadow-lg">
              <Info className="w-4.5 h-4.5 text-white" />
            </div>
            <div className="space-y-1">
              <p className="text-white text-sm font-medium">Echo TV – Music Player</p>
              <p className="text-white/40 text-xs">Version 2.0.0</p>
              <p className="text-white/40 text-xs mt-2">
                A YouTube-powered music player with Echo extension support. Stream any YouTube music video directly in your browser.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
