import { Play, Plus, TrendingUp, Clock, Music } from 'lucide-react';
import { useMusicStore, Song } from '../store/musicStore';

function SongCard({ song, onPlay }: { song: Song; onPlay: () => void }) {
  const { currentSong, isPlaying } = useMusicStore();
  const isActive = currentSong?.id === song.id;

  return (
    <div
      onClick={onPlay}
      className={`group relative flex flex-col gap-3 p-3 rounded-2xl cursor-pointer transition-all duration-200 hover:scale-[1.02] ${
        isActive ? 'bg-white/15 ring-1 ring-violet-500/50' : 'bg-white/5 hover:bg-white/10'
      }`}
    >
      <div className="relative aspect-video rounded-xl overflow-hidden">
        <img
          src={song.thumbnail}
          alt={song.title}
          className="w-full h-full object-cover transition-transform group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
        <div className={`absolute inset-0 flex items-center justify-center transition-opacity duration-200 ${isActive ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}>
          <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center border border-white/30">
            {isActive && isPlaying ? (
              <div className="flex gap-0.5 items-end h-4">
                {[0, 1, 2].map((i) => (
                  <div
                    key={i}
                    className="w-0.5 bg-white rounded-full animate-bounce"
                    style={{ height: `${6 + i * 3}px`, animationDelay: `${i * 0.15}s` }}
                  />
                ))}
              </div>
            ) : (
              <Play className="w-4 h-4 text-white fill-white ml-0.5" />
            )}
          </div>
        </div>
        {isActive && (
          <div className="absolute top-2 left-2">
            <span className="bg-violet-500 text-white text-xs px-2 py-0.5 rounded-full font-medium">
              Now Playing
            </span>
          </div>
        )}
      </div>
      <div className="min-w-0">
        <p className="text-white text-sm font-medium truncate leading-tight">{song.title}</p>
        <p className="text-white/50 text-xs truncate mt-0.5">{song.artist}</p>
        {song.duration && (
          <p className="text-white/30 text-xs mt-1">{song.duration}</p>
        )}
      </div>
    </div>
  );
}

function RecentRow({ song, onPlay }: { song: Song; onPlay: () => void }) {
  const { currentSong, isPlaying } = useMusicStore();
  const isActive = currentSong?.id === song.id;

  return (
    <div
      onClick={onPlay}
      className={`flex items-center gap-3 p-3 rounded-xl cursor-pointer transition-all group ${
        isActive ? 'bg-white/15' : 'hover:bg-white/8'
      }`}
    >
      <div className="relative shrink-0">
        <img
          src={song.thumbnail}
          alt={song.title}
          className="w-11 h-11 rounded-lg object-cover"
        />
        {isActive && isPlaying && (
          <div className="absolute inset-0 rounded-lg flex items-center justify-center bg-black/30">
            <div className="flex gap-0.5 items-end h-3">
              {[0, 1, 2].map((i) => (
                <div
                  key={i}
                  className="w-0.5 bg-white rounded-full animate-bounce"
                  style={{ height: `${5 + i * 2}px`, animationDelay: `${i * 0.15}s` }}
                />
              ))}
            </div>
          </div>
        )}
      </div>
      <div className="min-w-0 flex-1">
        <p className={`text-sm font-medium truncate ${isActive ? 'text-violet-300' : 'text-white'}`}>
          {song.title}
        </p>
        <p className="text-white/50 text-xs truncate">{song.artist}</p>
      </div>
      <div className="flex items-center gap-2 shrink-0">
        {song.duration && <span className="text-white/30 text-xs">{song.duration}</span>}
        <button className="opacity-0 group-hover:opacity-100 transition-opacity p-1 rounded-lg bg-white/10 hover:bg-white/20">
          <Play className="w-3.5 h-3.5 text-white fill-white" />
        </button>
      </div>
    </div>
  );
}

export default function HomeView() {
  const { playlist, playSong, setShowAddModal, currentSong } = useMusicStore();

  const featured = playlist.slice(0, 6);
  const recent = [...playlist].sort((a, b) => (b.addedAt ?? 0) - (a.addedAt ?? 0)).slice(0, 5);

  return (
    <div className="flex-1 overflow-y-auto">
      <div className="max-w-5xl mx-auto p-5 md:p-8 space-y-8">
        {/* Hero */}
        {currentSong ? (
          <div className="relative rounded-2xl overflow-hidden bg-gradient-to-r from-violet-900/60 to-pink-900/40 border border-white/10 p-6 flex gap-5 items-center">
            <img
              src={currentSong.thumbnail}
              alt={currentSong.title}
              className="w-20 h-20 md:w-28 md:h-28 rounded-xl object-cover shadow-2xl shrink-0"
            />
            <div className="min-w-0">
              <p className="text-white/50 text-xs uppercase tracking-widest mb-1">Now Playing</p>
              <h2 className="text-white font-bold text-xl md:text-2xl leading-tight truncate">{currentSong.title}</h2>
              <p className="text-white/60 mt-1">{currentSong.artist}</p>
              <div className="flex items-center gap-1 mt-2">
                <div className="flex gap-0.5 items-end h-4">
                  {[0,1,2,3].map((i) => (
                    <div
                      key={i}
                      className="w-1 bg-violet-400 rounded-full animate-bounce"
                      style={{ height: `${8+i*3}px`, animationDelay: `${i*0.1}s` }}
                    />
                  ))}
                </div>
                <span className="text-violet-400 text-xs ml-2">Live</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="relative rounded-2xl overflow-hidden border border-white/10 p-8 text-center bg-gradient-to-br from-violet-900/30 to-pink-900/20">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-violet-500 to-pink-500 flex items-center justify-center mx-auto mb-4 shadow-xl">
              <Music className="w-8 h-8 text-white" />
            </div>
            <h2 className="text-white font-bold text-2xl mb-2">Welcome to Echo TV</h2>
            <p className="text-white/50 text-sm mb-6">Your personal YouTube music player</p>
            <button
              onClick={() => setShowAddModal(true)}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-pink-600 text-white font-medium hover:opacity-90 transition-all shadow-lg"
            >
              <Plus className="w-4 h-4" />
              Add your first song
            </button>
          </div>
        )}

        {/* Featured */}
        {featured.length > 0 && (
          <section>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-violet-400" />
                <h3 className="text-white font-semibold">Featured</h3>
              </div>
              <button
                onClick={() => setShowAddModal(true)}
                className="text-white/40 hover:text-white text-xs flex items-center gap-1 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                Add song
              </button>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 gap-3">
              {featured.map((song, i) => (
                <SongCard
                  key={song.id}
                  song={song}
                  onPlay={() => playSong(song, i)}
                />
              ))}
            </div>
          </section>
        )}

        {/* Recently Added */}
        {recent.length > 0 && (
          <section>
            <div className="flex items-center gap-2 mb-4">
              <Clock className="w-4 h-4 text-violet-400" />
              <h3 className="text-white font-semibold">Recently Added</h3>
            </div>
            <div className="bg-white/5 rounded-2xl overflow-hidden divide-y divide-white/5">
              {recent.map((song) => {
                const idx = playlist.findIndex((s) => s.id === song.id);
                return (
                  <RecentRow
                    key={song.id}
                    song={song}
                    onPlay={() => playSong(song, idx)}
                  />
                );
              })}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
