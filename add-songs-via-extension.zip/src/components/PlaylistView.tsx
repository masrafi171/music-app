import { useState } from 'react';
import { Play, Trash2, Plus, Music, GripVertical, Pause } from 'lucide-react';
import { useMusicStore, Song } from '../store/musicStore';

function SongRow({
  song,
  index,
  onPlay,
  onRemove,
}: {
  song: Song;
  index: number;
  onPlay: () => void;
  onRemove: () => void;
}) {
  const { currentSong, isPlaying } = useMusicStore();
  const isActive = currentSong?.id === song.id;

  return (
    <div
      className={`group flex items-center gap-3 px-4 py-3 rounded-xl transition-all cursor-pointer ${
        isActive ? 'bg-violet-500/20 border border-violet-500/30' : 'hover:bg-white/5 border border-transparent'
      }`}
    >
      {/* Grip */}
      <div className="text-white/20 group-hover:text-white/40 transition-colors shrink-0">
        <GripVertical className="w-4 h-4" />
      </div>

      {/* Number / Play */}
      <div className="w-6 shrink-0 text-center" onClick={onPlay}>
        {isActive && isPlaying ? (
          <div className="flex gap-0.5 items-end h-4 justify-center">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className="w-0.5 bg-violet-400 rounded-full animate-bounce"
                style={{ height: `${5 + i * 3}px`, animationDelay: `${i * 0.15}s` }}
              />
            ))}
          </div>
        ) : (
          <span className="text-white/30 text-xs group-hover:hidden">{index + 1}</span>
        )}
        {!isActive && (
          <Play className="w-3.5 h-3.5 text-white hidden group-hover:block fill-white" />
        )}
        {isActive && !isPlaying && (
          <Pause className="w-3.5 h-3.5 text-violet-400 fill-violet-400" onClick={onPlay} />
        )}
      </div>

      {/* Thumbnail */}
      <div className="relative shrink-0" onClick={onPlay}>
        <img
          src={song.thumbnail}
          alt={song.title}
          className="w-10 h-10 rounded-lg object-cover"
        />
      </div>

      {/* Info */}
      <div className="min-w-0 flex-1" onClick={onPlay}>
        <p className={`text-sm font-medium truncate ${isActive ? 'text-violet-300' : 'text-white'}`}>
          {song.title}
        </p>
        <p className="text-white/50 text-xs truncate">{song.artist}</p>
      </div>

      {/* Duration */}
      {song.duration && (
        <span className="text-white/30 text-xs tabular-nums shrink-0 hidden sm:block">
          {song.duration}
        </span>
      )}

      {/* Remove */}
      <button
        onClick={(e) => { e.stopPropagation(); onRemove(); }}
        className="opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded-lg text-white/40 hover:text-red-400 hover:bg-red-400/10"
      >
        <Trash2 className="w-4 h-4" />
      </button>
    </div>
  );
}

export default function PlaylistView() {
  const { playlist, playSong, removeSong, setShowAddModal } = useMusicStore();
  const [confirmRemove, setConfirmRemove] = useState<string | null>(null);

  const totalDuration = playlist.reduce((acc, song) => {
    if (!song.duration) return acc;
    const [m, s] = song.duration.split(':').map(Number);
    return acc + m * 60 + s;
  }, 0);

  const formatTotal = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    return h > 0 ? `${h}h ${m}m` : `${m}m`;
  };

  const handleRemove = (id: string) => {
    if (confirmRemove === id) {
      removeSong(id);
      setConfirmRemove(null);
    } else {
      setConfirmRemove(id);
      setTimeout(() => setConfirmRemove(null), 2000);
    }
  };

  return (
    <div className="flex-1 overflow-y-auto">
      <div className="max-w-3xl mx-auto p-5 md:p-8">
        {/* Header */}
        <div className="flex items-end justify-between mb-6">
          <div>
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-violet-500 to-pink-500 flex items-center justify-center mb-3 shadow-xl shadow-violet-500/20">
              <Music className="w-7 h-7 text-white" />
            </div>
            <h1 className="text-white font-bold text-2xl">My Playlist</h1>
            <p className="text-white/40 text-sm mt-1">
              {playlist.length} songs
              {totalDuration > 0 && ` • ${formatTotal(totalDuration)}`}
            </p>
          </div>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-violet-600 to-pink-600 text-white text-sm font-medium hover:opacity-90 transition-all shadow-lg"
          >
            <Plus className="w-4 h-4" />
            Add Song
          </button>
        </div>

        {/* Play All */}
        {playlist.length > 0 && (
          <div className="flex gap-3 mb-6">
            <button
              onClick={() => playSong(playlist[0], 0)}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white text-black text-sm font-semibold hover:bg-white/90 transition-all shadow-lg"
            >
              <Play className="w-4 h-4 fill-black" />
              Play All
            </button>
          </div>
        )}

        {/* Song List */}
        {playlist.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center mx-auto mb-4">
              <Music className="w-8 h-8 text-white/20" />
            </div>
            <p className="text-white/40 text-sm mb-4">Your playlist is empty</p>
            <button
              onClick={() => setShowAddModal(true)}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-violet-600 text-white text-sm font-medium hover:bg-violet-500 transition-colors"
            >
              <Plus className="w-4 h-4" />
              Add your first song
            </button>
          </div>
        ) : (
          <div className="space-y-1">
            {playlist.map((song, index) => (
              <div key={song.id} className="relative">
                <SongRow
                  song={song}
                  index={index}
                  onPlay={() => playSong(song, index)}
                  onRemove={() => handleRemove(song.id)}
                />
                {confirmRemove === song.id && (
                  <div className="absolute right-2 top-1/2 -translate-y-1/2 bg-red-500 text-white text-xs px-2 py-1 rounded-lg z-10 pointer-events-none">
                    Click again to remove
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
