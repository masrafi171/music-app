import { Home, Search, ListMusic, Settings, Plus } from 'lucide-react';
import { useMusicStore } from '../store/musicStore';

const navItems = [
  { icon: Home, label: 'Home', view: 'home' as const },
  { icon: Search, label: 'Search', view: 'search' as const },
  { icon: ListMusic, label: 'Playlist', view: 'playlist' as const },
  { icon: Settings, label: 'Settings', view: 'settings' as const },
];

export default function MobileNav() {
  const { activeView, setActiveView, setShowAddModal } = useMusicStore();

  return (
    <div className="md:hidden fixed bottom-[80px] left-0 right-0 z-40 bg-black/80 backdrop-blur-xl border-t border-white/10">
      <div className="flex items-center justify-around px-2 py-2">
        {navItems.map(({ icon: Icon, label, view }) => (
          <button
            key={view}
            onClick={() => setActiveView(view)}
            className={`flex flex-col items-center gap-1 px-4 py-1.5 rounded-xl transition-all ${
              activeView === view ? 'text-violet-400' : 'text-white/40'
            }`}
          >
            <Icon className="w-5 h-5" />
            <span className="text-[10px] font-medium">{label}</span>
          </button>
        ))}
        <button
          onClick={() => setShowAddModal(true)}
          className="flex flex-col items-center gap-1 px-4 py-1.5 rounded-xl text-pink-400"
        >
          <Plus className="w-5 h-5" />
          <span className="text-[10px] font-medium">Add</span>
        </button>
      </div>
    </div>
  );
}
