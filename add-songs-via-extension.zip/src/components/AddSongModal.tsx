import { useState } from 'react';
import { X, Link2, Search, Plus, Loader2, CheckCircle } from 'lucide-react';
import { useMusicStore, Song } from '../store/musicStore';

function extractVideoId(url: string): string | null {
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/v\/)([a-zA-Z0-9_-]{11})/,
    /^([a-zA-Z0-9_-]{11})$/,
  ];
  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match) return match[1];
  }
  return null;
}

async function fetchVideoInfo(videoId: string): Promise<{ title: string; author: string } | null> {
  try {
    const res = await fetch(`https://noembed.com/embed?url=https://www.youtube.com/watch?v=${videoId}`);
    const data = await res.json();
    if (data.title) {
      return { title: data.title, author: data.author_name || 'Unknown Artist' };
    }
  } catch (_) {}
  return null;
}

export default function AddSongModal() {
  const { showAddModal, setShowAddModal, addSong } = useMusicStore();
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [preview, setPreview] = useState<Song | null>(null);

  const handleClose = () => {
    setShowAddModal(false);
    setUrl('');
    setError('');
    setSuccess(false);
    setPreview(null);
  };

  const handleFetch = async () => {
    setError('');
    setSuccess(false);
    setPreview(null);
    const trimmed = url.trim();
    if (!trimmed) {
      setError('Please enter a YouTube URL or video ID');
      return;
    }
    const videoId = extractVideoId(trimmed);
    if (!videoId) {
      setError('Invalid YouTube URL. Please paste a valid YouTube link.');
      return;
    }
    setLoading(true);
    const info = await fetchVideoInfo(videoId);
    setLoading(false);
    if (!info) {
      setError('Could not fetch video info. Please check the URL.');
      return;
    }
    setPreview({
      id: `yt-${videoId}-${Date.now()}`,
      videoId,
      title: info.title,
      artist: info.author,
      thumbnail: `https://img.youtube.com/vi/${videoId}/mqdefault.jpg`,
      addedAt: Date.now(),
    });
  };

  const handleAdd = () => {
    if (!preview) return;
    addSong(preview);
    setSuccess(true);
    setTimeout(() => {
      handleClose();
    }, 1200);
  };

  if (!showAddModal) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/70 backdrop-blur-sm"
        onClick={handleClose}
      />

      {/* Modal */}
      <div className="relative w-full max-w-md bg-gradient-to-b from-zinc-900 to-zinc-950 rounded-2xl border border-white/10 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-red-500/20 flex items-center justify-center">
              <svg className="w-4 h-4 text-red-400" viewBox="0 0 24 24" fill="currentColor">
                <path d="M23.5 6.2a3 3 0 0 0-2.1-2.1C19.5 3.5 12 3.5 12 3.5s-7.5 0-9.4.6A3 3 0 0 0 .5 6.2C0 8.1 0 12 0 12s0 3.9.5 5.8a3 3 0 0 0 2.1 2.1c1.9.6 9.4.6 9.4.6s7.5 0 9.4-.6a3 3 0 0 0 2.1-2.1C24 15.9 24 12 24 12s0-3.9-.5-5.8zM9.75 15.5v-7l6.25 3.5-6.25 3.5z"/>
              </svg>
            </div>
            <div>
              <h2 className="text-white font-semibold text-sm">Add via YouTube Extension</h2>
              <p className="text-white/40 text-xs">Paste a YouTube URL or video ID</p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="text-white/40 hover:text-white transition-colors p-1.5 rounded-lg hover:bg-white/10"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4">
          {/* URL Input */}
          <div className="space-y-2">
            <label className="text-white/60 text-xs font-medium uppercase tracking-wide flex items-center gap-1.5">
              <Link2 className="w-3 h-3" />
              YouTube URL or Video ID
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={url}
                onChange={(e) => { setUrl(e.target.value); setError(''); }}
                onKeyDown={(e) => e.key === 'Enter' && handleFetch()}
                placeholder="https://www.youtube.com/watch?v=..."
                className="flex-1 bg-white/8 border border-white/10 rounded-xl px-3 py-2.5 text-white text-sm placeholder-white/25 focus:outline-none focus:border-violet-500/50 focus:bg-white/10 transition-all"
              />
              <button
                onClick={handleFetch}
                disabled={loading}
                className="px-3 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white transition-colors flex items-center gap-1.5 text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
              </button>
            </div>
            {error && (
              <p className="text-red-400 text-xs flex items-center gap-1">
                <span className="w-1 h-1 rounded-full bg-red-400" />
                {error}
              </p>
            )}
          </div>

          {/* Example URLs */}
          <div className="space-y-1.5">
            <p className="text-white/30 text-xs font-medium">Examples:</p>
            {[
              'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
              'https://youtu.be/dQw4w9WgXcQ',
              'dQw4w9WgXcQ',
            ].map((ex) => (
              <button
                key={ex}
                onClick={() => setUrl(ex)}
                className="block text-xs text-violet-400/70 hover:text-violet-300 font-mono transition-colors truncate w-full text-left"
              >
                {ex}
              </button>
            ))}
          </div>

          {/* Preview */}
          {preview && (
            <div className="bg-white/5 border border-white/10 rounded-xl p-4 flex gap-3 items-center">
              <img
                src={preview.thumbnail}
                alt={preview.title}
                className="w-14 h-10 rounded-lg object-cover shrink-0"
              />
              <div className="min-w-0 flex-1">
                <p className="text-white text-sm font-medium truncate">{preview.title}</p>
                <p className="text-white/50 text-xs truncate">{preview.artist}</p>
              </div>
              {success ? (
                <CheckCircle className="w-5 h-5 text-green-400 shrink-0" />
              ) : (
                <button
                  onClick={handleAdd}
                  className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-violet-600 to-pink-600 text-white text-xs font-medium hover:opacity-90 transition-all flex items-center gap-1.5 shrink-0"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Add
                </button>
              )}
            </div>
          )}
        </div>

        {/* Extension Info Banner */}
        <div className="mx-5 mb-5 px-4 py-3 rounded-xl bg-gradient-to-r from-violet-500/10 to-pink-500/10 border border-violet-500/20">
          <p className="text-xs text-white/50 leading-relaxed">
            <span className="text-violet-400 font-medium">YouTube Extension</span> — Powered by{' '}
            <span className="text-white/70">echo-youtube-extension</span>. Paste any YouTube music
            URL to add songs directly to your playlist.
          </p>
        </div>
      </div>
    </div>
  );
}
