import { Home, Search, ListMusic, Settings, Music2, Plus } from 'lucide-react';
import { useMusicStore } from '../store/musicStore';

const navItems = [
  { icon: Home, label: 'Home', view: 'home' as const },
  { icon: Search, label: 'Search', view: 'search' as const },
  { icon: ListMusic, label: 'Playlist', view: 'playlist' as const },
  { icon: Settings, label: 'Settings', view: 'settings' as const },
];

export default function Sidebar() {
  const { activeView, setActiveView, setShowAddModal, playlist } = useMusicStore();

  return (
    <aside className="hidden md:flex flex-col w-60 bg-black/40 backdrop-blur-xl border-r border-white/10 h-full py-6 px-4 gap-2 shrink-0">
      {/* Logo */}
      <div className="flex items-center gap-3 px-2 mb-6">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-500 to-pink-500 flex items-center justify-center shadow-lg">
          <Music2 className="w-5 h-5 text-white" />
        </div>
        <span className="text-white font-bold text-lg tracking-tight">Echo TV</span>
      </div>

      {/* Nav */}
      <nav className="flex flex-col gap-1 flex-1">
        {navItems.map(({ icon: Icon, label, view }) => (
          <button
            key={view}
            onClick={() => setActiveView(view)}
            className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 ${
              activeView === view
                ? 'bg-white/15 text-white shadow-inner'
                : 'text-white/60 hover:text-white hover:bg-white/8'
            }`}
          >
            <Icon className="w-4.5 h-4.5" />
            {label}
            {view === 'playlist' && (
              <span className="ml-auto bg-violet-500/30 text-violet-300 text-xs px-1.5 py-0.5 rounded-full">
                {playlist.length}
              </span>
            )}
          </button>
        ))}
      </nav>

      {/* Add Song Button */}
      <button
        onClick={() => setShowAddModal(true)}
        className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-pink-600 text-white text-sm font-medium hover:opacity-90 transition-all shadow-lg shadow-violet-500/20 active:scale-95"
      >
        <Plus className="w-4 h-4" />
        Add via YouTube
      </button>

      {/* Extension badge */}
      <div className="mt-2 px-3 py-3 rounded-xl bg-white/5 border border-white/10">
        <div className="flex items-center gap-2 mb-1">
          <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
          <span className="text-xs text-white/60 font-medium">YouTube Extension</span>
        </div>
        <p className="text-xs text-white/40">Connected & active</p>
      </div>
    </aside>
  );
}
