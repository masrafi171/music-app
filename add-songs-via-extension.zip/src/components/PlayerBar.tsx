import { useRef } from 'react';
import {
  Play, Pause, SkipBack, SkipForward, Volume2, VolumeX,
  Shuffle, Repeat, Repeat1, Heart, ListMusic,
} from 'lucide-react';
import { useMusicStore } from '../store/musicStore';
import { seekTo } from './YouTubePlayer';

function formatTime(seconds: number) {
  if (!seconds || isNaN(seconds)) return '0:00';
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
}

export default function PlayerBar() {
  const {
    currentSong, isPlaying, togglePlay,
    nextSong, prevSong,
    volume, isMuted, setVolume, toggleMute,
    isShuffled, toggleShuffle,
    repeatMode, toggleRepeat,
    currentTime, duration,
    setActiveView,
  } = useMusicStore();

  const progressRef = useRef<HTMLDivElement>(null);

  const handleProgressClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!progressRef.current || !duration) return;
    const rect = progressRef.current.getBoundingClientRect();
    const ratio = (e.clientX - rect.left) / rect.width;
    const seekTime = ratio * duration;
    seekTo(seekTime);
  };

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div className="h-20 md:h-24 bg-black/60 backdrop-blur-2xl border-t border-white/10 flex items-center px-4 md:px-6 gap-4 shrink-0">
      {/* Song Info */}
      <div className="flex items-center gap-3 min-w-0 w-52 shrink-0">
        {currentSong ? (
          <>
            <div className="relative shrink-0">
              <img
                src={currentSong.thumbnail}
                alt={currentSong.title}
                className="w-12 h-12 rounded-lg object-cover shadow-lg"
              />
              {isPlaying && (
                <div className="absolute inset-0 rounded-lg flex items-center justify-center bg-black/20">
                  <div className="flex gap-0.5 items-end h-4">
                    {[0, 1, 2].map((i) => (
                      <div
                        key={i}
                        className="w-0.5 bg-white rounded-full animate-bounce"
                        style={{
                          height: `${8 + i * 4}px`,
                          animationDelay: `${i * 0.15}s`,
                          animationDuration: '0.8s',
                        }}
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>
            <div className="min-w-0">
              <p className="text-white text-sm font-medium truncate">{currentSong.title}</p>
              <p className="text-white/50 text-xs truncate">{currentSong.artist}</p>
            </div>
            <button className="text-white/40 hover:text-pink-400 transition-colors ml-1 shrink-0">
              <Heart className="w-4 h-4" />
            </button>
          </>
        ) : (
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-lg bg-white/10 flex items-center justify-center">
              <ListMusic className="w-5 h-5 text-white/30" />
            </div>
            <div>
              <p className="text-white/30 text-sm">No song selected</p>
              <p className="text-white/20 text-xs">Choose a track</p>
            </div>
          </div>
        )}
      </div>

      {/* Center Controls */}
      <div className="flex-1 flex flex-col items-center gap-1.5 min-w-0">
        {/* Buttons */}
        <div className="flex items-center gap-3">
          <button
            onClick={toggleShuffle}
            className={`transition-colors p-1.5 rounded-lg ${isShuffled ? 'text-violet-400 bg-violet-500/20' : 'text-white/50 hover:text-white'}`}
          >
            <Shuffle className="w-4 h-4" />
          </button>
          <button
            onClick={prevSong}
            className="text-white/80 hover:text-white transition-colors p-1.5 rounded-lg hover:bg-white/10"
          >
            <SkipBack className="w-5 h-5 fill-current" />
          </button>
          <button
            onClick={togglePlay}
            disabled={!currentSong}
            className={`w-10 h-10 rounded-full flex items-center justify-center transition-all shadow-lg ${
              currentSong
                ? 'bg-white text-black hover:scale-105 active:scale-95 shadow-white/20'
                : 'bg-white/20 text-white/30 cursor-not-allowed'
            }`}
          >
            {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current ml-0.5" />}
          </button>
          <button
            onClick={nextSong}
            className="text-white/80 hover:text-white transition-colors p-1.5 rounded-lg hover:bg-white/10"
          >
            <SkipForward className="w-5 h-5 fill-current" />
          </button>
          <button
            onClick={toggleRepeat}
            className={`transition-colors p-1.5 rounded-lg ${repeatMode !== 'none' ? 'text-violet-400 bg-violet-500/20' : 'text-white/50 hover:text-white'}`}
          >
            {repeatMode === 'one' ? <Repeat1 className="w-4 h-4" /> : <Repeat className="w-4 h-4" />}
          </button>
        </div>

        {/* Progress Bar */}
        <div className="flex items-center gap-2 w-full max-w-lg">
          <span className="text-white/40 text-xs tabular-nums w-8 text-right shrink-0">
            {formatTime(currentTime)}
          </span>
          <div
            ref={progressRef}
            onClick={handleProgressClick}
            className="flex-1 h-1.5 bg-white/15 rounded-full cursor-pointer group relative overflow-hidden"
          >
            <div
              className="h-full bg-gradient-to-r from-violet-500 to-pink-500 rounded-full transition-all relative"
              style={{ width: `${progressPercent}%` }}
            >
              <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-white shadow-lg opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
          </div>
          <span className="text-white/40 text-xs tabular-nums w-8 shrink-0">
            {formatTime(duration)}
          </span>
        </div>
      </div>

      {/* Volume */}
      <div className="hidden md:flex items-center gap-2 w-36 shrink-0 justify-end">
        <button
          onClick={toggleMute}
          className="text-white/50 hover:text-white transition-colors"
        >
          {isMuted || volume === 0 ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
        </button>
        <div className="relative flex-1 h-1.5 bg-white/15 rounded-full cursor-pointer group">
          <input
            type="range"
            min={0}
            max={100}
            value={isMuted ? 0 : volume}
            onChange={(e) => setVolume(Number(e.target.value))}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
          />
          <div
            className="h-full bg-gradient-to-r from-violet-500 to-pink-500 rounded-full"
            style={{ width: `${isMuted ? 0 : volume}%` }}
          />
        </div>
        <span className="text-white/30 text-xs w-7 text-right tabular-nums">
          {isMuted ? 0 : volume}
        </span>
      </div>

      {/* Mobile Playlist Toggle */}
      <button
        className="md:hidden text-white/50 hover:text-white"
        onClick={() => setActiveView('playlist')}
      >
        <ListMusic className="w-5 h-5" />
      </button>
    </div>
  );
}
