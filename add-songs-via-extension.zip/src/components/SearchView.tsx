import { useState } from 'react';
import { Search, Plus, Play, Loader2, CheckCircle2, AlertCircle, ExternalLink } from 'lucide-react';
import { useMusicStore, Song } from '../store/musicStore';

function extractVideoId(url: string): string | null {
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/v\/)([a-zA-Z0-9_-]{11})/,
    /^([a-zA-Z0-9_-]{11})$/,
  ];
  for (const p of patterns) {
    const m = url.match(p);
    if (m) return m[1];
  }
  return null;
}

async function fetchVideoInfo(videoId: string): Promise<{ title: string; author: string } | null> {
  try {
    const res = await fetch(`https://noembed.com/embed?url=https://www.youtube.com/watch?v=${videoId}`);
    const data = await res.json();
    if (data.title && !data.error) return { title: data.title, author: data.author_name || 'Unknown' };
  } catch (_) {}
  return null;
}

export default function SearchView() {
  const { addSong, playSong, playlist } = useMusicStore();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Song[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [addedIds, setAddedIds] = useState<Set<string>>(new Set());

  const isInPlaylist = (videoId: string) => playlist.some((s) => s.videoId === videoId);

  const handleSearch = async () => {
    setError('');
    const trimmed = query.trim();
    if (!trimmed) return;

    const videoId = extractVideoId(trimmed);
    if (videoId) {
      setLoading(true);
      const info = await fetchVideoInfo(videoId);
      setLoading(false);
      if (info) {
        setResults([
          {
            id: `search-${videoId}`,
            videoId,
            title: info.title,
            artist: info.author,
            thumbnail: `https://img.youtube.com/vi/${videoId}/mqdefault.jpg`,
          },
        ]);
      } else {
        setError('Could not load video info. Please check the URL.');
      }
      return;
    }

    // Fallback: show manual entry tip
    setError('Enter a YouTube URL or video ID to add songs. Keyword search requires a YouTube API key.');
    setResults([]);
  };

  const handleAdd = (song: Song) => {
    const newSong = { ...song, id: `yt-${song.videoId}-${Date.now()}` };
    addSong(newSong);
    setAddedIds((prev) => new Set([...prev, song.videoId]));
  };

  const handlePlay = (song: Song) => {
    const existing = playlist.find((s) => s.videoId === song.videoId);
    if (existing) {
      const idx = playlist.indexOf(existing);
      playSong(existing, idx);
    } else {
      const newSong = { ...song, id: `yt-${song.videoId}-${Date.now()}` };
      addSong(newSong);
      setTimeout(() => {
        const updated = useMusicStore.getState().playlist;
        const added = updated.find((s) => s.videoId === song.videoId);
        if (added) playSong(added, updated.indexOf(added));
      }, 50);
    }
  };

  const quickExamples = [
    { label: 'Lo-fi Hip Hop', id: 'jfKfPfyJRdk' },
    { label: 'Blinding Lights', id: '4NRXx6U8ABQ' },
    { label: 'Levitating', id: 'TlV5sOwP_a0' },
    { label: 'Watermelon Sugar', id: 'E07s5ZYygMg' },
    { label: 'drivers license', id: 'ZmDBbnmKpqQ' },
    { label: 'Stay', id: 'bd9r2w_YNhM' },
  ];

  const handleQuickAdd = async (id: string, label: string) => {
    setLoading(true);
    const info = await fetchVideoInfo(id);
    setLoading(false);
    const song: Song = {
      id: `yt-${id}-${Date.now()}`,
      videoId: id,
      title: info?.title ?? label,
      artist: info?.author ?? 'YouTube',
      thumbnail: `https://img.youtube.com/vi/${id}/mqdefault.jpg`,
      addedAt: Date.now(),
    };
    addSong(song);
    setAddedIds((prev) => new Set([...prev, id]));
  };

  return (
    <div className="flex-1 overflow-y-auto">
      <div className="max-w-3xl mx-auto p-5 md:p-8 space-y-6">
        <div>
          <h1 className="text-white font-bold text-2xl mb-1">Search & Add Songs</h1>
          <p className="text-white/40 text-sm">Paste a YouTube URL or video ID to add songs</p>
        </div>

        {/* Search Bar */}
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
            <input
              type="text"
              value={query}
              onChange={(e) => { setQuery(e.target.value); setError(''); }}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              placeholder="Paste YouTube URL or video ID..."
              className="w-full bg-white/8 border border-white/10 rounded-xl pl-10 pr-4 py-3 text-white text-sm placeholder-white/25 focus:outline-none focus:border-violet-500/50 focus:bg-white/12 transition-all"
            />
          </div>
          <button
            onClick={handleSearch}
            disabled={loading}
            className="px-4 py-3 rounded-xl bg-violet-600 hover:bg-violet-500 text-white font-medium text-sm transition-colors flex items-center gap-2 disabled:opacity-50"
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
            Search
          </button>
        </div>

        {error && (
          <div className="flex items-start gap-2 p-3 rounded-xl bg-yellow-500/10 border border-yellow-500/20">
            <AlertCircle className="w-4 h-4 text-yellow-400 shrink-0 mt-0.5" />
            <p className="text-yellow-300 text-sm">{error}</p>
          </div>
        )}

        {/* Search Results */}
        {results.length > 0 && (
          <div className="space-y-2">
            <h3 className="text-white/60 text-xs font-semibold uppercase tracking-widest">Result</h3>
            {results.map((song) => (
              <div
                key={song.videoId}
                className="flex items-center gap-3 p-3 rounded-xl bg-white/8 border border-white/10 hover:bg-white/12 transition-all group"
              >
                <img
                  src={song.thumbnail}
                  alt={song.title}
                  className="w-14 h-10 rounded-lg object-cover shrink-0"
                />
                <div className="min-w-0 flex-1">
                  <p className="text-white text-sm font-medium truncate">{song.title}</p>
                  <p className="text-white/50 text-xs truncate">{song.artist}</p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <a
                    href={`https://www.youtube.com/watch?v=${song.videoId}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-1.5 rounded-lg text-white/30 hover:text-white/60 transition-colors"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                  <button
                    onClick={() => handlePlay(song)}
                    className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors"
                  >
                    <Play className="w-4 h-4 fill-white" />
                  </button>
                  <button
                    onClick={() => handleAdd(song)}
                    disabled={isInPlaylist(song.videoId) || addedIds.has(song.videoId)}
                    className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium transition-colors ${
                      isInPlaylist(song.videoId) || addedIds.has(song.videoId)
                        ? 'bg-green-500/20 text-green-400 cursor-default'
                        : 'bg-violet-600 hover:bg-violet-500 text-white'
                    }`}
                  >
                    {isInPlaylist(song.videoId) || addedIds.has(song.videoId) ? (
                      <><CheckCircle2 className="w-3.5 h-3.5" /> Added</>
                    ) : (
                      <><Plus className="w-3.5 h-3.5" /> Add</>
                    )}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Quick Add Section */}
        <div>
          <h3 className="text-white/60 text-xs font-semibold uppercase tracking-widest mb-3">
            Quick Add — Popular Songs
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {quickExamples.map(({ label, id }) => (
              <div
                key={id}
                className="flex items-center gap-3 p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-all border border-white/5 group"
              >
                <img
                  src={`https://img.youtube.com/vi/${id}/default.jpg`}
                  alt={label}
                  className="w-10 h-10 rounded-lg object-cover shrink-0"
                />
                <div className="min-w-0 flex-1">
                  <p className="text-white text-sm font-medium truncate">{label}</p>
                  <p className="text-white/30 text-xs font-mono truncate">{id}</p>
                </div>
                <button
                  onClick={() => handleQuickAdd(id, label)}
                  disabled={isInPlaylist(id) || addedIds.has(id)}
                  className={`p-1.5 rounded-lg text-xs transition-colors shrink-0 ${
                    isInPlaylist(id) || addedIds.has(id)
                      ? 'text-green-400 cursor-default'
                      : 'text-white/50 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {isInPlaylist(id) || addedIds.has(id)
                    ? <CheckCircle2 className="w-4 h-4" />
                    : <Plus className="w-4 h-4" />
                  }
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* How it works */}
        <div className="rounded-2xl bg-gradient-to-r from-violet-500/10 to-pink-500/10 border border-violet-500/20 p-5">
          <h3 className="text-white font-semibold text-sm mb-3 flex items-center gap-2">
            <div className="w-5 h-5 rounded-full bg-violet-500/30 flex items-center justify-center">
              <span className="text-violet-300 text-xs">?</span>
            </div>
            How to add songs via YouTube Extension
          </h3>
          <ol className="space-y-2 text-sm text-white/60">
            <li className="flex gap-2"><span className="text-violet-400 font-bold shrink-0">1.</span> Copy a YouTube video URL from your browser</li>
            <li className="flex gap-2"><span className="text-violet-400 font-bold shrink-0">2.</span> Paste it in the search bar above</li>
            <li className="flex gap-2"><span className="text-violet-400 font-bold shrink-0">3.</span> Click Search to fetch song info</li>
            <li className="flex gap-2"><span className="text-violet-400 font-bold shrink-0">4.</span> Click Add to add it to your playlist</li>
          </ol>
          <div className="mt-3 pt-3 border-t border-white/10">
            <p className="text-xs text-white/30">
              Powered by{' '}
              <a
                href="https://github.com/brahmkshatriya/echo-youtube-extension-old"
                target="_blank"
                rel="noopener noreferrer"
                className="text-violet-400 hover:text-violet-300"
              >
                echo-youtube-extension
              </a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
