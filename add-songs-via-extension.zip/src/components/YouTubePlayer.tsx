import { useEffect, useRef, useCallback } from 'react';
import { useMusicStore } from '../store/musicStore';

declare global {
  interface Window {
    YT: any;
    onYouTubeIframeAPIReady: () => void;
    _ytPlayerInstance: any;
  }
}

export default function YouTubePlayer() {
  const playerRef = useRef<any>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const isReady = useRef(false);
  const progressInterval = useRef<number | null>(null);

  const {
    currentSong,
    isPlaying,
    volume,
    isMuted,
    setCurrentTime,
    setDuration,
    setIsPlaying,
    nextSong,
  } = useMusicStore();

  const startProgressTracker = useCallback(() => {
    if (progressInterval.current) clearInterval(progressInterval.current);
    progressInterval.current = window.setInterval(() => {
      if (playerRef.current && isReady.current) {
        try {
          const ct = playerRef.current.getCurrentTime?.() ?? 0;
          const dur = playerRef.current.getDuration?.() ?? 0;
          setCurrentTime(ct);
          setDuration(dur);
        } catch (_) {}
      }
    }, 500);
  }, [setCurrentTime, setDuration]);

  const stopProgressTracker = useCallback(() => {
    if (progressInterval.current) {
      clearInterval(progressInterval.current);
      progressInterval.current = null;
    }
  }, []);

  // Load YouTube IFrame API
  useEffect(() => {
    if (window.YT && window.YT.Player) {
      initPlayer();
      return;
    }

    const tag = document.createElement('script');
    tag.src = 'https://www.youtube.com/iframe_api';
    document.head.appendChild(tag);

    window.onYouTubeIframeAPIReady = () => {
      initPlayer();
    };

    return () => {
      stopProgressTracker();
    };
  }, []);

  const initPlayer = () => {
    if (!containerRef.current) return;
    if (playerRef.current) return;

    playerRef.current = new window.YT.Player(containerRef.current, {
      height: '100%',
      width: '100%',
      videoId: '',
      playerVars: {
        autoplay: 1,
        controls: 0,
        disablekb: 1,
        fs: 0,
        iv_load_policy: 3,
        modestbranding: 1,
        playsinline: 1,
        rel: 0,
        showinfo: 0,
      },
      events: {
        onReady: () => {
          isReady.current = true;
          window._ytPlayerInstance = playerRef.current;
          const state = useMusicStore.getState();
          playerRef.current.setVolume(state.isMuted ? 0 : state.volume);
        },
        onStateChange: (event: any) => {
          const YT = window.YT;
          if (event.data === YT.PlayerState.PLAYING) {
            setIsPlaying(true);
            startProgressTracker();
          } else if (
            event.data === YT.PlayerState.PAUSED ||
            event.data === YT.PlayerState.BUFFERING
          ) {
            if (event.data === YT.PlayerState.PAUSED) {
              setIsPlaying(false);
            }
            stopProgressTracker();
          } else if (event.data === YT.PlayerState.ENDED) {
            setIsPlaying(false);
            stopProgressTracker();
            nextSong();
          }
        },
        onError: () => {
          setIsPlaying(false);
          stopProgressTracker();
        },
      },
    });
  };

  // Load new video when currentSong changes
  useEffect(() => {
    if (!currentSong || !isReady.current || !playerRef.current) return;
    try {
      playerRef.current.loadVideoById({ videoId: currentSong.videoId, startSeconds: 0 });
    } catch (_) {}
  }, [currentSong?.videoId]);

  // Play/Pause
  useEffect(() => {
    if (!isReady.current || !playerRef.current) return;
    try {
      if (isPlaying) {
        playerRef.current.playVideo();
        startProgressTracker();
      } else {
        playerRef.current.pauseVideo();
        stopProgressTracker();
      }
    } catch (_) {}
  }, [isPlaying]);

  // Volume
  useEffect(() => {
    if (!isReady.current || !playerRef.current) return;
    try {
      playerRef.current.setVolume(isMuted ? 0 : volume);
    } catch (_) {}
  }, [volume, isMuted]);

  return (
    <div className="hidden">
      <div ref={containerRef} id="yt-player-container" />
    </div>
  );
}

// Expose seek function globally
export function seekTo(seconds: number) {
  if (window._ytPlayerInstance) {
    try {
      window._ytPlayerInstance.seekTo(seconds, true);
    } catch (_) {}
  }
}
