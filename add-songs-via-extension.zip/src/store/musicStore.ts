import { create } from 'zustand';

export interface Song {
  id: string;
  videoId: string;
  title: string;
  artist: string;
  thumbnail: string;
  duration?: string;
  addedAt?: number;
}

interface MusicState {
  playlist: Song[];
  currentSong: Song | null;
  currentIndex: number;
  isPlaying: boolean;
  volume: number;
  isMuted: boolean;
  isShuffled: boolean;
  repeatMode: 'none' | 'one' | 'all';
  currentTime: number;
  duration: number;
  searchQuery: string;
  searchResults: Song[];
  isSearching: boolean;
  activeView: 'home' | 'search' | 'playlist' | 'settings';
  showAddModal: boolean;
  youtubeUrl: string;

  // Actions
  addSong: (song: Song) => void;
  removeSong: (id: string) => void;
  playSong: (song: Song, index?: number) => void;
  togglePlay: () => void;
  nextSong: () => void;
  prevSong: () => void;
  setVolume: (v: number) => void;
  toggleMute: () => void;
  toggleShuffle: () => void;
  toggleRepeat: () => void;
  setCurrentTime: (t: number) => void;
  setDuration: (d: number) => void;
  setSearchQuery: (q: string) => void;
  setSearchResults: (results: Song[]) => void;
  setIsSearching: (v: boolean) => void;
  setActiveView: (v: 'home' | 'search' | 'playlist' | 'settings') => void;
  setShowAddModal: (v: boolean) => void;
  setYoutubeUrl: (url: string) => void;
  setIsPlaying: (v: boolean) => void;
  reorderPlaylist: (fromIndex: number, toIndex: number) => void;
}

const defaultPlaylist: Song[] = [
  {
    id: '1',
    videoId: 'dQw4w9WgXcQ',
    title: 'Never Gonna Give You Up',
    artist: 'Rick Astley',
    thumbnail: 'https://img.youtube.com/vi/dQw4w9WgXcQ/mqdefault.jpg',
    duration: '3:33',
    addedAt: Date.now() - 86400000,
  },
  {
    id: '2',
    videoId: 'kXYiU_JCYtU',
    title: 'Numb',
    artist: 'Linkin Park',
    thumbnail: 'https://img.youtube.com/vi/kXYiU_JCYtU/mqdefault.jpg',
    duration: '3:05',
    addedAt: Date.now() - 72000000,
  },
  {
    id: '3',
    videoId: 'fJ9rUzIMcZQ',
    title: 'Bohemian Rhapsody',
    artist: 'Queen',
    thumbnail: 'https://img.youtube.com/vi/fJ9rUzIMcZQ/mqdefault.jpg',
    duration: '5:55',
    addedAt: Date.now() - 43200000,
  },
  {
    id: '4',
    videoId: 'YQHsXMglC9A',
    title: 'Hello',
    artist: 'Adele',
    thumbnail: 'https://img.youtube.com/vi/YQHsXMglC9A/mqdefault.jpg',
    duration: '4:55',
    addedAt: Date.now() - 21600000,
  },
  {
    id: '5',
    videoId: 'JGwWNGJdvx8',
    title: 'Shape of You',
    artist: 'Ed Sheeran',
    thumbnail: 'https://img.youtube.com/vi/JGwWNGJdvx8/mqdefault.jpg',
    duration: '3:54',
    addedAt: Date.now() - 7200000,
  },
  {
    id: '6',
    videoId: 'hT_nvWreIhg',
    title: 'Counting Stars',
    artist: 'OneRepublic',
    thumbnail: 'https://img.youtube.com/vi/hT_nvWreIhg/mqdefault.jpg',
    duration: '4:17',
    addedAt: Date.now() - 3600000,
  },
  {
    id: '7',
    videoId: 'OPf0YbXqDm0',
    title: 'Mark Ronson - Uptown Funk ft. Bruno Mars',
    artist: 'Mark Ronson',
    thumbnail: 'https://img.youtube.com/vi/OPf0YbXqDm0/mqdefault.jpg',
    duration: '4:30',
    addedAt: Date.now() - 1800000,
  },
  {
    id: '8',
    videoId: 'CevxZvSJLk8',
    title: 'Katy Perry - Roar',
    artist: 'Katy Perry',
    thumbnail: 'https://img.youtube.com/vi/CevxZvSJLk8/mqdefault.jpg',
    duration: '3:43',
    addedAt: Date.now() - 900000,
  },
];

export const useMusicStore = create<MusicState>((set, _get) => ({
  playlist: defaultPlaylist,
  currentSong: null,
  currentIndex: -1,
  isPlaying: false,
  volume: 80,
  isMuted: false,
  isShuffled: false,
  repeatMode: 'none',
  currentTime: 0,
  duration: 0,
  searchQuery: '',
  searchResults: [],
  isSearching: false,
  activeView: 'home',
  showAddModal: false,
  youtubeUrl: '',

  addSong: (song) =>
    set((state) => {
      const exists = state.playlist.find((s) => s.videoId === song.videoId);
      if (exists) return state;
      return { playlist: [...state.playlist, { ...song, addedAt: Date.now() }] };
    }),

  removeSong: (id) =>
    set((state) => {
      const newPlaylist = state.playlist.filter((s) => s.id !== id);
      const removedIndex = state.playlist.findIndex((s) => s.id === id);
      let newCurrentIndex = state.currentIndex;
      if (removedIndex < state.currentIndex) newCurrentIndex--;
      else if (removedIndex === state.currentIndex) newCurrentIndex = -1;
      return {
        playlist: newPlaylist,
        currentIndex: newCurrentIndex,
        currentSong: newCurrentIndex >= 0 ? newPlaylist[newCurrentIndex] : null,
      };
    }),

  playSong: (song, index) =>
    set((state) => {
      const idx = index !== undefined ? index : state.playlist.findIndex((s) => s.id === song.id);
      return { currentSong: song, currentIndex: idx, isPlaying: true, currentTime: 0 };
    }),

  togglePlay: () => set((state) => ({ isPlaying: !state.isPlaying })),

  nextSong: () =>
    set((state) => {
      const { playlist, currentIndex, isShuffled, repeatMode } = state;
      if (playlist.length === 0) return state;
      let nextIndex: number;
      if (repeatMode === 'one') {
        nextIndex = currentIndex;
      } else if (isShuffled) {
        nextIndex = Math.floor(Math.random() * playlist.length);
      } else {
        nextIndex = currentIndex + 1;
        if (nextIndex >= playlist.length) {
          nextIndex = repeatMode === 'all' ? 0 : currentIndex;
        }
      }
      return {
        currentIndex: nextIndex,
        currentSong: playlist[nextIndex],
        isPlaying: true,
        currentTime: 0,
      };
    }),

  prevSong: () =>
    set((state) => {
      const { playlist, currentIndex, currentTime } = state;
      if (playlist.length === 0) return state;
      if (currentTime > 3) return { currentTime: 0 };
      const prevIndex = currentIndex <= 0 ? playlist.length - 1 : currentIndex - 1;
      return {
        currentIndex: prevIndex,
        currentSong: playlist[prevIndex],
        isPlaying: true,
        currentTime: 0,
      };
    }),

  setVolume: (v) => set({ volume: v, isMuted: v === 0 }),
  toggleMute: () => set((state) => ({ isMuted: !state.isMuted })),
  toggleShuffle: () => set((state) => ({ isShuffled: !state.isShuffled })),
  toggleRepeat: () =>
    set((state) => {
      const modes: Array<'none' | 'one' | 'all'> = ['none', 'all', 'one'];
      const currentIdx = modes.indexOf(state.repeatMode);
      return { repeatMode: modes[(currentIdx + 1) % modes.length] };
    }),

  setCurrentTime: (t) => set({ currentTime: t }),
  setDuration: (d) => set({ duration: d }),
  setSearchQuery: (q) => set({ searchQuery: q }),
  setSearchResults: (results) => set({ searchResults: results }),
  setIsSearching: (v) => set({ isSearching: v }),
  setActiveView: (v) => set({ activeView: v }),
  setShowAddModal: (v) => set({ showAddModal: v }),
  setYoutubeUrl: (url) => set({ youtubeUrl: url }),
  setIsPlaying: (v) => set({ isPlaying: v }),

  reorderPlaylist: (fromIndex, toIndex) =>
    set((state) => {
      const newPlaylist = [...state.playlist];
      const [moved] = newPlaylist.splice(fromIndex, 1);
      newPlaylist.splice(toIndex, 0, moved);
      let newCurrentIndex = state.currentIndex;
      if (state.currentIndex === fromIndex) newCurrentIndex = toIndex;
      else if (fromIndex < state.currentIndex && toIndex >= state.currentIndex) newCurrentIndex--;
      else if (fromIndex > state.currentIndex && toIndex <= state.currentIndex) newCurrentIndex++;
      return { playlist: newPlaylist, currentIndex: newCurrentIndex };
    }),
}));
