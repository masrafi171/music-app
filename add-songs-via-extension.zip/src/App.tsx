import { useMusicStore } from './store/musicStore';
import YouTubePlayer from './components/YouTubePlayer';
import Sidebar from './components/Sidebar';
import PlayerBar from './components/PlayerBar';
import AddSongModal from './components/AddSongModal';
import HomeView from './components/HomeView';
import PlaylistView from './components/PlaylistView';
import SearchView from './components/SearchView';
import SettingsView from './components/SettingsView';
import MobileNav from './components/MobileNav';

export default function App() {
  const { activeView } = useMusicStore();

  return (
    <div className="h-screen w-screen flex flex-col bg-[#0a0a0f] overflow-hidden">
      {/* Background gradient */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-violet-600/15 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-pink-600/10 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-indigo-600/8 rounded-full blur-3xl" />
      </div>

      {/* Hidden YouTube Player */}
      <YouTubePlayer />

      {/* Main Layout */}
      <div className="relative z-10 flex flex-1 min-h-0">
        {/* Sidebar - Desktop */}
        <Sidebar />

        {/* Main Content */}
        <main className="flex-1 flex flex-col min-w-0 min-h-0">
          {/* View Content */}
          <div className="flex-1 min-h-0 flex flex-col">
            {activeView === 'home' && <HomeView />}
            {activeView === 'search' && <SearchView />}
            {activeView === 'playlist' && <PlaylistView />}
            {activeView === 'settings' && <SettingsView />}
          </div>
        </main>
      </div>

      {/* Mobile Nav */}
      <MobileNav />

      {/* Player Bar */}
      <div className="relative z-20">
        <PlayerBar />
      </div>

      {/* Add Song Modal */}
      <AddSongModal />
    </div>
  );
}
