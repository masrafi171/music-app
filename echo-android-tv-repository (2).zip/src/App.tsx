import { useState } from "react";
import MusicHome from "./components/MusicHome";
import TVPlayer from "./components/TVPlayer";
import { songs } from "./data/songs";
import type { Song } from "./data/songs";

export default function App() {
  const [currentSong, setCurrentSong] = useState<Song | null>(null);
  const [playerOpen, setPlayerOpen] = useState(false);

  const handlePlay = (song: Song) => {
    setCurrentSong(song);
    setPlayerOpen(true);
  };

  const handleClose = () => {
    setPlayerOpen(false);
  };

  const handleNext = () => {
    if (!currentSong) return;
    const idx = songs.findIndex(s => s.id === currentSong.id);
    const next = songs[(idx + 1) % songs.length];
    setCurrentSong(next);
  };

  const handlePrev = () => {
    if (!currentSong) return;
    const idx = songs.findIndex(s => s.id === currentSong.id);
    const prev = songs[(idx - 1 + songs.length) % songs.length];
    setCurrentSong(prev);
  };

  return (
    <>
      <MusicHome
        onPlay={handlePlay}
        currentSong={playerOpen ? currentSong : null}
      />
      {playerOpen && currentSong && (
        <TVPlayer
          song={currentSong}
          onClose={handleClose}
          onNext={handleNext}
          onPrev={handlePrev}
        />
      )}
    </>
  );
}
