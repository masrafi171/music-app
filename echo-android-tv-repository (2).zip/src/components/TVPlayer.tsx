import { useState, useEffect, useRef, useCallback } from "react";
import type { Song } from "../data/songs";

function formatTime(s: number) {
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${sec.toString().padStart(2, "0")}`;
}

interface TVPlayerProps {
  song: Song;
  onClose: () => void;
  onNext: () => void;
  onPrev: () => void;
}

export default function TVPlayer({ song, onClose, onNext, onPrev }: TVPlayerProps) {
  const [playing, setPlaying] = useState(true);
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState(80);
  const [liked, setLiked] = useState(false);
  const [shuffle, setShuffle] = useState(false);
  const [repeat, setRepeat] = useState(false);
  const [activeLyricIdx, setActiveLyricIdx] = useState(0);
  const [_showControls, setShowControls] = useState(true);

  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const lyricsRef = useRef<HTMLDivElement>(null);
  const hideControlsTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Auto-play timer (simulate playback)
  useEffect(() => {
    setCurrentTime(0);
    setActiveLyricIdx(0);
    setPlaying(true);
  }, [song]);

  useEffect(() => {
    if (playing) {
      intervalRef.current = setInterval(() => {
        setCurrentTime((t) => {
          if (t >= song.duration - 1) {
            clearInterval(intervalRef.current!);
            setPlaying(false);
            return song.duration;
          }
          return t + 1;
        });
      }, 1000);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [playing, song.duration]);

  // Sync lyrics
  useEffect(() => {
    let idx = 0;
    for (let i = 0; i < song.lyrics.length; i++) {
      if (currentTime >= song.lyrics[i].time) idx = i;
      else break;
    }
    setActiveLyricIdx(idx);
  }, [currentTime, song.lyrics]);

  // Scroll active lyric into view
  useEffect(() => {
    if (lyricsRef.current) {
      const activeEl = lyricsRef.current.querySelector(".lyric-active");
      if (activeEl) {
        activeEl.scrollIntoView({ behavior: "smooth", block: "center" });
      }
    }
  }, [activeLyricIdx]);

  // Auto-hide controls
  const resetControlsTimer = useCallback(() => {
    setShowControls(true);
    if (hideControlsTimer.current) clearTimeout(hideControlsTimer.current);
    hideControlsTimer.current = setTimeout(() => setShowControls(false), 4000);
  }, []);

  useEffect(() => {
    resetControlsTimer();
    return () => { if (hideControlsTimer.current) clearTimeout(hideControlsTimer.current); };
  }, [resetControlsTimer]);

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const ratio = (e.clientX - rect.left) / rect.width;
    const newTime = Math.floor(ratio * song.duration);
    setCurrentTime(Math.max(0, Math.min(newTime, song.duration)));
    resetControlsTimer();
  };

  const handleVolumeSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const ratio = (e.clientX - rect.left) / rect.width;
    setVolume(Math.round(Math.max(0, Math.min(ratio * 100, 100))));
    resetControlsTimer();
  };

  const progress = (currentTime / song.duration) * 100;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center"
      style={{ background: `linear-gradient(135deg, ${song.color}ee 0%, #0a0a14 60%, #0d0d1a 100%)` }}
      onMouseMove={resetControlsTimer}
      onClick={resetControlsTimer}
    >
      {/* Ambient blurred bg */}
      <div
        className="absolute inset-0 opacity-30 blur-3xl scale-110 pointer-events-none"
        style={{
          backgroundImage: `url(${song.cover})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      />
      <div className="absolute inset-0 bg-black/50 pointer-events-none" />

      {/* Back button */}
      <button
        onClick={onClose}
        className="absolute top-6 left-6 z-10 flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 hover:bg-white/20 text-white text-sm font-medium backdrop-blur-sm border border-white/10 transition-all duration-200"
      >
        ← Back
      </button>

      {/* "lyric metro" watermark */}
      <div className="absolute bottom-5 right-6 text-white/20 text-xs font-medium z-10">
        lyric metro
      </div>

      {/* Main layout */}
      <div className="relative z-10 w-full max-w-6xl mx-auto px-8 flex flex-col md:flex-row items-center md:items-start gap-10 py-16">

        {/* LEFT: Player card */}
        <div className="w-full md:w-[340px] flex-shrink-0">
          {/* Album art */}
          <div className="relative rounded-2xl overflow-hidden shadow-2xl shadow-black/60 mb-4 aspect-[4/3]">
            <img
              src={song.cover}
              alt={song.title}
              className="w-full h-full object-cover"
            />
            {/* Song title overlay on image */}
            <div className="absolute top-3 left-4">
              <div className="text-white font-black text-2xl uppercase tracking-widest leading-none drop-shadow-lg">
                {song.title.toUpperCase()}
              </div>
              <div className="text-white/60 text-xs mt-1 tracking-wider drop-shadow">
                {song.title} | {song.artist.split(" ")[0]}
              </div>
            </div>
          </div>

          {/* Song info row */}
          <div className="flex items-center justify-between mb-4 px-1">
            <div>
              <div className="text-white font-semibold text-base leading-tight">{song.title}</div>
              <div className="text-white/50 text-sm">{song.artist} — {song.album}</div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setLiked(l => !l)}
                className={`w-9 h-9 rounded-full flex items-center justify-center border transition-all duration-200 ${liked ? "border-yellow-400 text-yellow-400 bg-yellow-400/10" : "border-white/20 text-white/50 hover:border-white/40 hover:text-white"}`}
              >
                ★
              </button>
              <button className="w-9 h-9 rounded-full flex items-center justify-center border border-white/20 text-white/50 hover:border-white/40 hover:text-white transition-all duration-200">
                ⋯
              </button>
            </div>
          </div>

          {/* Progress bar */}
          <div className="mb-1 px-1">
            <div
              className="h-1 rounded-full bg-white/20 cursor-pointer relative group"
              onClick={handleSeek}
            >
              <div
                className="h-full rounded-full bg-white transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
              <div
                className="absolute top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full shadow-md opacity-0 group-hover:opacity-100 transition-opacity"
                style={{ left: `calc(${progress}% - 6px)` }}
              />
            </div>
          </div>
          <div className="flex justify-between text-white/40 text-xs px-1 mb-4">
            <span>{formatTime(currentTime)}</span>
            <span>-{formatTime(song.duration - currentTime)}</span>
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center gap-5 mb-4">
            <button
              onClick={() => setShuffle(s => !s)}
              className={`text-lg transition-colors ${shuffle ? "text-white" : "text-white/40 hover:text-white/70"}`}
              title="Shuffle"
            >
              ⇄
            </button>
            <button
              onClick={onPrev}
              className="text-white/70 hover:text-white text-2xl transition-colors"
              title="Previous"
            >
              ⏮
            </button>
            <button
              onClick={() => setPlaying(p => !p)}
              className="w-12 h-12 rounded-full bg-white text-black flex items-center justify-center text-xl hover:scale-105 transition-transform shadow-lg"
            >
              {playing ? "⏸" : "▶"}
            </button>
            <button
              onClick={onNext}
              className="text-white/70 hover:text-white text-2xl transition-colors"
              title="Next"
            >
              ⏭
            </button>
            <button
              onClick={() => setRepeat(r => !r)}
              className={`text-lg transition-colors ${repeat ? "text-white" : "text-white/40 hover:text-white/70"}`}
              title="Repeat"
            >
              ↺
            </button>
          </div>

          {/* Volume */}
          <div className="flex items-center gap-3 px-1">
            <span className="text-white/40 text-sm">🔈</span>
            <div
              className="flex-1 h-1 rounded-full bg-white/20 cursor-pointer relative group"
              onClick={handleVolumeSeek}
            >
              <div
                className="h-full rounded-full bg-white/70 transition-all duration-200"
                style={{ width: `${volume}%` }}
              />
            </div>
            <span className="text-white/40 text-xs w-7 text-right">{volume}</span>
          </div>
        </div>

        {/* RIGHT: Lyrics */}
        <div
          ref={lyricsRef}
          className="flex-1 max-h-[70vh] overflow-y-auto pr-2 lyrics-scroll"
          style={{ maskImage: "linear-gradient(to bottom, transparent 0%, black 15%, black 75%, transparent 100%)" }}
        >
          <div className="flex flex-col gap-6 py-24">
            {song.lyrics.map((line, i) => {
              const isActive = i === activeLyricIdx;
              const isPast = i < activeLyricIdx;
              const isNear = Math.abs(i - activeLyricIdx) <= 2;
              return (
                <div
                  key={i}
                  className={`lyric-line cursor-pointer transition-all duration-500 select-none ${isActive ? "lyric-active" : ""}`}
                  onClick={() => {
                    setCurrentTime(line.time);
                    resetControlsTimer();
                  }}
                  style={{
                    fontSize: isActive ? "2.2rem" : isNear ? "1.5rem" : "1.25rem",
                    fontWeight: isActive ? 800 : isNear ? 600 : 500,
                    color: isActive
                      ? "#ffffff"
                      : isPast
                      ? "rgba(255,255,255,0.25)"
                      : isNear
                      ? "rgba(255,255,255,0.55)"
                      : "rgba(255,255,255,0.2)",
                    lineHeight: 1.3,
                    transform: isActive ? "translateX(0)" : "none",
                    textShadow: isActive ? "0 0 40px rgba(255,255,255,0.3)" : "none",
                    transition: "all 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94)",
                  }}
                >
                  {line.text}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Floating D-Pad hint (TV remote style) */}
      <div className="absolute bottom-5 left-1/2 -translate-x-1/2 flex items-center gap-3 text-white/20 text-xs">
        <span>🕹️ D-Pad Navigation Ready</span>
      </div>
    </div>
  );
}
