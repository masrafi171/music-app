import { useState } from "react";
import { songs, playlists } from "../data/songs";
import type { Song } from "../data/songs";

interface MusicHomeProps {
  onPlay: (song: Song) => void;
  currentSong: Song | null;
}

function SongCard({ song, onPlay, isPlaying }: { song: Song; onPlay: () => void; isPlaying: boolean }) {
  const [hovered, setHovered] = useState(false);
  return (
    <div
      className="group cursor-pointer"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onClick={onPlay}
    >
      <div className="relative rounded-xl overflow-hidden mb-3 aspect-square shadow-lg">
        <img
          src={song.cover}
          alt={song.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        {/* Hover overlay */}
        <div className={`absolute inset-0 bg-black/50 flex items-center justify-center transition-opacity duration-300 ${hovered || isPlaying ? "opacity-100" : "opacity-0"}`}>
          <div className={`w-14 h-14 rounded-full bg-white flex items-center justify-center shadow-2xl transition-transform duration-300 ${hovered ? "scale-100" : "scale-75"}`}>
            {isPlaying ? (
              <div className="flex items-end gap-[3px] h-5">
                {[1,2,3,4].map(i => (
                  <div key={i} className="w-1 bg-black rounded-full" style={{
                    animation: `waveBar 0.5s ease-in-out ${i * 0.1}s infinite alternate`,
                    height: "100%"
                  }} />
                ))}
              </div>
            ) : (
              <span className="text-black text-2xl ml-1">▶</span>
            )}
          </div>
        </div>
        {isPlaying && (
          <div className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-white text-black text-[10px] font-bold">
            NOW PLAYING
          </div>
        )}
      </div>
      <div>
        <div className={`font-semibold text-sm truncate transition-colors ${isPlaying ? "text-purple-300" : "text-white group-hover:text-purple-200"}`}>
          {song.title}
        </div>
        <div className="text-white/50 text-xs truncate">{song.artist}</div>
      </div>
    </div>
  );
}

function SongRow({ song, index, onPlay, isPlaying }: { song: Song; index: number; onPlay: () => void; isPlaying: boolean }) {
  function formatTime(s: number) {
    return `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, "0")}`;
  }
  return (
    <div
      className={`group flex items-center gap-4 px-4 py-3 rounded-xl cursor-pointer transition-all duration-200 ${isPlaying ? "bg-purple-500/20 border border-purple-500/30" : "hover:bg-white/5 border border-transparent"}`}
      onClick={onPlay}
    >
      <div className="w-6 text-center">
        {isPlaying ? (
          <div className="flex items-end justify-center gap-[2px] h-4">
            {[1,2,3].map(i => (
              <div key={i} className="w-0.5 bg-purple-400 rounded-full" style={{
                animation: `waveBar 0.5s ease-in-out ${i * 0.12}s infinite alternate`,
                height: "100%"
              }} />
            ))}
          </div>
        ) : (
          <span className="text-white/30 text-sm group-hover:hidden">{index + 1}</span>
        )}
        {!isPlaying && <span className="hidden group-hover:inline text-white text-sm">▶</span>}
      </div>
      <img src={song.cover} alt={song.title} className="w-10 h-10 rounded-lg object-cover flex-shrink-0" />
      <div className="flex-1 min-w-0">
        <div className={`text-sm font-medium truncate ${isPlaying ? "text-purple-300" : "text-white"}`}>{song.title}</div>
        <div className="text-white/40 text-xs truncate">{song.artist} · {song.album}</div>
      </div>
      <div className="text-white/30 text-xs flex-shrink-0">{formatTime(song.duration)}</div>
    </div>
  );
}

const NAV_ITEMS = ["Home", "Explore", "Library", "Podcasts"];

export default function MusicHome({ onPlay, currentSong }: MusicHomeProps) {
  const [activeNav, setActiveNav] = useState("Home");
  const [search, setSearch] = useState("");
  const [searchFocused, setSearchFocused] = useState(false);

  const filtered = search
    ? songs.filter(
        s =>
          s.title.toLowerCase().includes(search.toLowerCase()) ||
          s.artist.toLowerCase().includes(search.toLowerCase())
      )
    : [];

  return (
    <div className="min-h-screen bg-[#0f0f14] text-white flex flex-col" style={{ fontFamily: "'Inter', sans-serif" }}>
      <style>{`
        @keyframes waveBar {
          from { transform: scaleY(0.3); }
          to   { transform: scaleY(1); }
        }
      `}</style>

      {/* ===== TOP NAV ===== */}
      <header className="sticky top-0 z-40 bg-[#0f0f14]/90 backdrop-blur-xl border-b border-white/5">
        <div className="flex items-center gap-4 px-6 py-4">
          {/* Logo */}
          <div className="flex items-center gap-2 mr-4 flex-shrink-0">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: "linear-gradient(135deg,#9333ea,#4f46e5)" }}>
              <span className="text-white text-lg">🎵</span>
            </div>
            <span className="font-bold text-white text-base hidden sm:block">Echo<span className="text-purple-400"> TV</span></span>
          </div>

          {/* Nav tabs */}
          <nav className="hidden md:flex items-center gap-1">
            {NAV_ITEMS.map(item => (
              <button
                key={item}
                onClick={() => setActiveNav(item)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${activeNav === item ? "bg-white text-black" : "text-white/60 hover:text-white hover:bg-white/10"}`}
              >
                {item}
              </button>
            ))}
          </nav>

          {/* Search */}
          <div className={`relative ml-auto flex items-center gap-2 px-4 py-2 rounded-full border transition-all duration-300 ${searchFocused ? "border-purple-500 bg-purple-500/10 w-64" : "border-white/10 bg-white/5 w-40"}`}>
            <span className="text-white/40 text-sm flex-shrink-0">🔍</span>
            <input
              type="text"
              placeholder="Search songs..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              onFocus={() => setSearchFocused(true)}
              onBlur={() => setTimeout(() => setSearchFocused(false), 200)}
              className="bg-transparent text-white text-sm outline-none placeholder-white/30 w-full"
            />
            {search && (
              <button onClick={() => setSearch("")} className="text-white/30 hover:text-white text-xs flex-shrink-0">✕</button>
            )}
          </div>

          {/* Avatar */}
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
            M
          </div>
        </div>

        {/* Search results dropdown */}
        {search && filtered.length > 0 && (
          <div className="absolute top-full left-0 right-0 bg-[#1a1a24] border-b border-white/10 shadow-2xl z-50 max-h-60 overflow-y-auto">
            {filtered.map(song => (
              <div
                key={song.id}
                className="flex items-center gap-3 px-6 py-3 hover:bg-white/5 cursor-pointer transition-colors"
                onClick={() => { onPlay(song); setSearch(""); }}
              >
                <img src={song.cover} alt={song.title} className="w-9 h-9 rounded-lg object-cover" />
                <div>
                  <div className="text-white text-sm font-medium">{song.title}</div>
                  <div className="text-white/40 text-xs">{song.artist}</div>
                </div>
                <span className="ml-auto text-purple-400 text-xs">▶ Play</span>
              </div>
            ))}
          </div>
        )}
      </header>

      {/* ===== MAIN CONTENT ===== */}
      <main className="flex-1 overflow-y-auto px-6 py-8 max-w-7xl mx-auto w-full">

        {/* Hero banner */}
        <div
          className="relative rounded-3xl overflow-hidden mb-10 h-52 cursor-pointer group"
          style={{ background: "linear-gradient(135deg, #2d1b69 0%, #1a0a3e 50%, #0f0822 100%)" }}
          onClick={() => onPlay(songs[0])}
        >
          <div className="absolute inset-0 opacity-30" style={{ backgroundImage: `url(${songs[0].cover})`, backgroundSize: "cover", backgroundPosition: "center", filter: "blur(4px)" }} />
          <div className="absolute inset-0 bg-gradient-to-r from-[#1a0a3e]/90 via-[#1a0a3e]/60 to-transparent" />
          <div className="relative z-10 h-full flex items-center px-10 gap-6">
            <img src={songs[0].cover} alt={songs[0].title} className="w-28 h-28 rounded-2xl object-cover shadow-2xl group-hover:scale-105 transition-transform duration-300 hidden sm:block" />
            <div>
              <div className="text-purple-300 text-xs font-bold uppercase tracking-widest mb-1">🔥 Featured Track</div>
              <h1 className="text-white text-3xl font-black mb-1">{songs[0].title}</h1>
              <p className="text-white/60 text-sm mb-4">{songs[0].artist} · {songs[0].album}</p>
              <button
                className="flex items-center gap-2 px-5 py-2.5 rounded-full font-semibold text-sm text-white transition-all duration-200 hover:scale-105 hover:shadow-xl hover:shadow-purple-600/40"
                style={{ background: "linear-gradient(135deg, #9333ea, #4f46e5)" }}
              >
                ▶ Play Now
              </button>
            </div>
            <div className="ml-auto hidden lg:flex items-center gap-2 text-white/30 text-xs">
              <span>🎵 Lyrics Sync</span>
              <span className="w-1 h-1 rounded-full bg-white/20" />
              <span>TV Optimized</span>
            </div>
          </div>
        </div>

        {/* Quick picks grid */}
        <section className="mb-10">
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-white font-bold text-xl">Quick picks</h2>
            <button className="text-purple-400 text-sm hover:text-purple-300 transition-colors">Shuffle all ⇄</button>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {songs.map(song => (
              <SongCard
                key={song.id}
                song={song}
                onPlay={() => onPlay(song)}
                isPlaying={currentSong?.id === song.id}
              />
            ))}
          </div>
        </section>

        {/* Playlists */}
        <section className="mb-10">
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-white font-bold text-xl">Playlists for you</h2>
          </div>
          <div className="flex gap-3 flex-wrap">
            {playlists.map(pl => (
              <button
                key={pl.id}
                className="flex items-center gap-2 px-5 py-2.5 rounded-full border border-white/10 bg-white/5 text-white/70 text-sm font-medium hover:border-purple-500/50 hover:bg-purple-500/10 hover:text-white transition-all duration-200"
              >
                🎶 {pl.name}
              </button>
            ))}
          </div>
        </section>

        {/* All songs list */}
        <section>
          <div className="flex items-center justify-between mb-5">
            <h2 className="text-white font-bold text-xl">All Songs</h2>
            <span className="text-white/30 text-sm">{songs.length} tracks</span>
          </div>
          <div className="rounded-2xl border border-white/5 bg-white/[0.02] overflow-hidden">
            {/* Header */}
            <div className="flex items-center gap-4 px-4 py-2 border-b border-white/5 text-white/30 text-xs">
              <div className="w-6 text-center">#</div>
              <div className="w-10 flex-shrink-0" />
              <div className="flex-1">TITLE</div>
              <div className="text-right flex-shrink-0">DURATION</div>
            </div>
            {songs.map((song, i) => (
              <SongRow
                key={song.id}
                song={song}
                index={i}
                onPlay={() => onPlay(song)}
                isPlaying={currentSong?.id === song.id}
              />
            ))}
          </div>
        </section>

      </main>

      {/* ===== MINI PLAYER BAR (when song selected) ===== */}
      {currentSong && (
        <div
          className="sticky bottom-0 z-40 border-t border-white/10 backdrop-blur-xl bg-[#0f0f14]/95 px-6 py-3 flex items-center gap-4 cursor-pointer hover:bg-purple-500/10 transition-colors group"
          onClick={() => onPlay(currentSong)}
        >
          <img src={currentSong.cover} alt={currentSong.title} className="w-11 h-11 rounded-lg object-cover flex-shrink-0" />
          <div className="flex-1 min-w-0">
            <div className="text-white font-medium text-sm truncate">{currentSong.title}</div>
            <div className="text-white/40 text-xs truncate">{currentSong.artist}</div>
          </div>
          {/* Mini wave */}
          <div className="flex items-end gap-[3px] h-4 mr-2">
            {[1,2,3,4,5].map(i => (
              <div key={i} className="w-0.5 bg-purple-400 rounded-full" style={{
                animation: `waveBar 0.5s ease-in-out ${i * 0.1}s infinite alternate`,
                height: "100%"
              }} />
            ))}
          </div>
          <div className="text-purple-400 text-xs font-medium group-hover:text-purple-300 transition-colors flex-shrink-0">
            Open Player →
          </div>
        </div>
      )}
    </div>
  );
}
