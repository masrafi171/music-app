export interface LyricLine {
  time: number; // in seconds
  text: string;
}

export interface Song {
  id: number;
  title: string;
  artist: string;
  album: string;
  duration: number; // seconds
  cover: string;
  color: string; // dominant color for bg gradient
  lyrics: LyricLine[];
}

export const songs: Song[] = [
  {
    id: 1,
    title: "Khat",
    artist: "Navjot Ahuja",
    album: "Khat - Single",
    duration: 244,
    cover: "/album-khat.jpg",
    color: "#1a2a4a",
    lyrics: [
      { time: 0,   text: "♪ Instrumental ♪" },
      { time: 8,   text: "Pasand hai tumhe, maloom hai" },
      { time: 14,  text: "Tumne bataya tha ek dafe" },
      { time: 20,  text: "Neele phool laau tere liye" },
      { time: 26,  text: "Khat likhu tere liye" },
      { time: 32,  text: "Mai khuda me maanu nahi" },
      { time: 38,  text: "Par dua karta hoon teri" },
      { time: 44,  text: "Teri aankhon mein jo sapne hain" },
      { time: 50,  text: "Sab poore ho jaaye" },
      { time: 56,  text: "Pasand hai tumhe, maloom hai" },
      { time: 62,  text: "Dil se kehta hoon yeh baat" },
      { time: 68,  text: "Har subah teri yaad aati hai" },
      { time: 74,  text: "Aur har raat bhi..." },
      { time: 80,  text: "Khat likhu tere liye" },
      { time: 86,  text: "Lafzon mein dil kholun" },
      { time: 92,  text: "Tujhe bataaun jo na keh saka" },
      { time: 98,  text: "Woh sab kahun" },
      { time: 104, text: "♪ Instrumental ♪" },
      { time: 116, text: "Pasand hai tumhe, maloom hai" },
      { time: 122, text: "Tumne bataya tha ek dafe" },
      { time: 128, text: "Neele phool laau tere liye" },
      { time: 134, text: "Khat likhu tere liye" },
      { time: 140, text: "Mai khuda me maanu nahi" },
      { time: 146, text: "Par dua karta hoon teri" },
      { time: 152, text: "Teri aankhon mein jo sapne hain" },
      { time: 158, text: "Sab poore ho jaaye..." },
      { time: 170, text: "♪ Outro ♪" },
    ],
  },
  {
    id: 2,
    title: "Raataan Lambiyan",
    artist: "Jubin Nautiyal",
    album: "Shershaah",
    duration: 214,
    cover: "/album-cover2.jpg",
    color: "#2a1040",
    lyrics: [
      { time: 0,   text: "♪ Instrumental ♪" },
      { time: 10,  text: "Raataan lambiyan, roz sapne dekhan" },
      { time: 16,  text: "Teri yaad mein kho jaana" },
      { time: 22,  text: "Chand sitaare, poochhe mere dil se" },
      { time: 28,  text: "Kyun hai tujhe chaahna" },
      { time: 34,  text: "Lambiyan si judaai, teri yaad sataye" },
      { time: 40,  text: "Dil yeh kehta rahe" },
      { time: 46,  text: "Aa ja, aa ja mere paas aa ja" },
      { time: 52,  text: "Tujhe dil ne pukara hai" },
      { time: 58,  text: "Raataan lambiyan..." },
      { time: 64,  text: "♪ Instrumental ♪" },
      { time: 76,  text: "Khwaab toote na, ankhein bheegi hain" },
      { time: 82,  text: "Par tujhe bhula nahi sakta" },
      { time: 88,  text: "Tu hi meri duniya, tu hi mera dil hai" },
      { time: 94,  text: "Tere bina jee nahi sakta" },
      { time: 100, text: "Raataan lambiyan, roz sapne dekhan" },
      { time: 106, text: "Teri yaad mein kho jaana" },
      { time: 112, text: "♪ Outro ♪" },
    ],
  },
  {
    id: 3,
    title: "Neon Lights",
    artist: "Echo Band",
    album: "City Dreams",
    duration: 198,
    cover: "/album-cover3.jpg",
    color: "#0d1a2a",
    lyrics: [
      { time: 0,   text: "♪ Intro ♪" },
      { time: 8,   text: "Neon lights flicker in the rain" },
      { time: 14,  text: "City streets hold all my pain" },
      { time: 20,  text: "Shadows dance on every wall" },
      { time: 26,  text: "And I answer when you call" },
      { time: 32,  text: "Through the night we find our way" },
      { time: 38,  text: "Chasing dreams till break of day" },
      { time: 44,  text: "Neon lights, neon lights" },
      { time: 50,  text: "Guide me through these endless nights" },
      { time: 56,  text: "♪ Instrumental ♪" },
      { time: 68,  text: "Every corner tells a story" },
      { time: 74,  text: "Of forgotten souls and glory" },
      { time: 80,  text: "But in this city I found you" },
      { time: 86,  text: "Underneath the midnight blue" },
      { time: 92,  text: "Neon lights, neon lights" },
      { time: 98,  text: "Guide me through these endless nights" },
      { time: 104, text: "♪ Outro ♪" },
    ],
  },
  {
    id: 4,
    title: "Golden Hour",
    artist: "Strumming Hearts",
    album: "Acoustic Sessions",
    duration: 232,
    cover: "/album-cover4.jpg",
    color: "#2a1a08",
    lyrics: [
      { time: 0,   text: "♪ Acoustic Intro ♪" },
      { time: 10,  text: "In the golden hour I see your face" },
      { time: 16,  text: "Sunlight painting every trace" },
      { time: 22,  text: "Of the memories we made" },
      { time: 28,  text: "In the warmth that never fades" },
      { time: 34,  text: "Strum a chord and let it ring" },
      { time: 40,  text: "Hear the joy that life can bring" },
      { time: 46,  text: "Golden hour, golden hour" },
      { time: 52,  text: "Stay a little longer please" },
      { time: 58,  text: "♪ Instrumental ♪" },
      { time: 70,  text: "Fields of amber, skies of rose" },
      { time: 76,  text: "Only heaven really knows" },
      { time: 82,  text: "How a single setting sun" },
      { time: 88,  text: "Makes two hearts beat as one" },
      { time: 94,  text: "Golden hour, golden hour" },
      { time: 100, text: "Never let this feeling cease" },
      { time: 106, text: "♪ Outro ♪" },
    ],
  },
];

export const playlists = [
  { id: 1, name: "Top Picks", songs: [1, 2, 3, 4] },
  { id: 2, name: "Trending Now", songs: [2, 1, 4, 3] },
  { id: 3, name: "Chill Vibes", songs: [4, 3, 1, 2] },
];
