import { useState, useEffect, useRef } from "react";

// ---- Animated waveform bars ----
function WaveBars({ count = 5, color = "#a855f7" }: { count?: number; color?: string }) {
  return (
    <span className="inline-flex items-end gap-[3px] h-5">
      {Array.from({ length: count }).map((_, i) => (
        <span
          key={i}
          style={{
            backgroundColor: color,
            width: 3,
            borderRadius: 2,
            display: "inline-block",
            animation: `wave ${0.6 + i * 0.15}s ease-in-out infinite alternate`,
            animationDelay: `${i * 0.1}s`,
          }}
          className="h-full"
        />
      ))}
    </span>
  );
}

// ---- Feature card ----
function FeatureCard({
  icon,
  title,
  desc,
  done,
}: {
  icon: string;
  title: string;
  desc: string;
  done: boolean;
}) {
  return (
    <div className="group relative rounded-2xl border border-white/10 bg-white/5 backdrop-blur-sm p-6 hover:border-purple-500/50 hover:bg-purple-500/10 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-purple-900/30">
      <div className="flex items-start gap-4">
        <div className="text-3xl">{icon}</div>
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <h3 className="text-white font-semibold text-base">{title}</h3>
            {done ? (
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-green-500/20 text-green-400 border border-green-500/30">
                DONE
              </span>
            ) : (
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-yellow-500/20 text-yellow-400 border border-yellow-500/30">
                WIP
              </span>
            )}
          </div>
          <p className="text-white/50 text-sm leading-relaxed">{desc}</p>
        </div>
      </div>
    </div>
  );
}

// ---- Tech badge ----
function TechBadge({ label, emoji }: { label: string; emoji: string }) {
  return (
    <div className="flex items-center gap-2 px-4 py-2 rounded-full border border-white/10 bg-white/5 text-white/80 text-sm font-medium hover:border-purple-500/50 hover:bg-purple-500/10 transition-all duration-200 cursor-default">
      <span>{emoji}</span>
      <span>{label}</span>
    </div>
  );
}

// ---- Step card ----
function StepCard({
  num,
  title,
  code,
}: {
  num: string;
  title: string;
  code: string;
}) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 backdrop-blur-sm p-5 hover:border-purple-500/40 transition-all duration-300">
      <div className="flex items-center gap-3 mb-3">
        <span className="w-7 h-7 rounded-full bg-purple-600 text-white text-xs font-bold flex items-center justify-center flex-shrink-0">
          {num}
        </span>
        <span className="text-white/80 font-medium text-sm">{title}</span>
      </div>
      <div className="relative">
        <pre className="bg-black/40 rounded-xl px-4 py-3 text-purple-300 text-xs font-mono overflow-x-auto border border-white/5">
          {code}
        </pre>
        <button
          onClick={copy}
          className="absolute top-2 right-2 text-[10px] px-2 py-1 rounded-lg bg-white/10 text-white/60 hover:bg-purple-600 hover:text-white transition-all duration-200"
        >
          {copied ? "✓ Copied" : "Copy"}
        </button>
      </div>
    </div>
  );
}

// ---- Stat card ----
function StatCard({ num, label, icon }: { num: string; label: string; icon: string }) {
  return (
    <div className="flex flex-col items-center gap-1 px-6 py-4 rounded-2xl border border-white/10 bg-white/5 backdrop-blur-sm min-w-[120px]">
      <span className="text-2xl">{icon}</span>
      <span className="text-2xl font-bold text-white">{num}</span>
      <span className="text-white/50 text-xs text-center">{label}</span>
    </div>
  );
}

// ---- Navbar ----
function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", handler);
    return () => window.removeEventListener("scroll", handler);
  }, []);
  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-black/80 backdrop-blur-xl border-b border-white/10 shadow-lg"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-2xl">🎵</span>
          <span className="text-white font-bold text-lg tracking-tight font-[Space_Grotesk]">
            Echo <span className="text-purple-400">TV</span>
          </span>
        </div>
        <div className="hidden md:flex items-center gap-6 text-white/60 text-sm font-medium">
          <a href="#features" className="hover:text-white transition-colors">Features</a>
          <a href="#tech" className="hover:text-white transition-colors">Tech Stack</a>
          <a href="#install" className="hover:text-white transition-colors">Install</a>
          <a
            href="https://github.com/masrafi17/echo-android-tv"
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 text-white text-sm hover:bg-purple-600 transition-all duration-200 border border-white/10"
          >
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2C6.477 2 2 6.477 2 12c0 4.418 2.865 8.166 6.839 9.489.5.092.682-.217.682-.482 0-.237-.008-.866-.013-1.7-2.782.603-3.369-1.34-3.369-1.34-.454-1.156-1.11-1.464-1.11-1.464-.908-.62.069-.608.069-.608 1.003.07 1.531 1.03 1.531 1.03.892 1.529 2.341 1.087 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.11-4.555-4.943 0-1.091.39-1.984 1.029-2.683-.103-.253-.446-1.27.098-2.647 0 0 .84-.269 2.75 1.025A9.578 9.578 0 0 1 12 6.836c.85.004 1.705.115 2.504.337 1.909-1.294 2.747-1.025 2.747-1.025.546 1.377.203 2.394.1 2.647.64.699 1.028 1.592 1.028 2.683 0 3.842-2.339 4.687-4.566 4.935.359.309.678.919.678 1.852 0 1.336-.012 2.415-.012 2.743 0 .267.18.578.688.48C19.138 20.163 22 16.418 22 12c0-5.523-4.477-10-10-10z" />
            </svg>
            GitHub
          </a>
        </div>
      </div>
    </nav>
  );
}

// ---- Main App ----
export default function App() {
  const heroRef = useRef<HTMLDivElement>(null);

  const features = [
    { icon: "📺", title: "Android TV Leanback UI", desc: "Built specifically for big screens with TV-optimized UI components and beautiful layouts.", done: true },
    { icon: "🕹️", title: "D-Pad Navigation", desc: "Fully optimized for remote control navigation. Smooth focus management across all screens.", done: true },
    { icon: "🔌", title: "Echo Extension Support", desc: "Load music from various sources dynamically using Echo's powerful extension architecture.", done: true },
    { icon: "🖥️", title: "Large Clean UI Elements", desc: "Every element is designed for readability from 3 meters away. Minimal and elegant.", done: true },
    { icon: "🎯", title: "Focus Management", desc: "Intelligent focus handling ensures smooth navigation without losing track of position.", done: true },
    { icon: "▶️", title: "Playback Controls", desc: "Full-featured playback with play, pause, seek, volume, and queue management.", done: false },
    { icon: "📋", title: "Playlist Management", desc: "Create, edit, and manage playlists directly from your TV remote.", done: false },
    { icon: "🔍", title: "Search Functionality", desc: "Quick and responsive search across all your music sources and libraries.", done: false },
  ];

  const techStack = [
    { label: "Kotlin", emoji: "🟣" },
    { label: "Android TV Leanback", emoji: "📺" },
    { label: "MVVM Architecture", emoji: "🏗️" },
    { label: "Clean Architecture", emoji: "✨" },
    { label: "Echo Extensions", emoji: "🔌" },
    { label: "Gradle", emoji: "🔧" },
    { label: "Android SDK 31+", emoji: "🤖" },
    { label: "Kotlin 1.9+", emoji: "🚀" },
  ];

  const steps = [
    { num: "1", title: "Clone the repository", code: "git clone https://github.com/masrafi17/echo-android-tv.git\ncd echo-android-tv" },
    { num: "2", title: "Open in Android Studio", code: "# Open Android Studio Giraffe or newer\n# File → Open → select the folder" },
    { num: "3", title: "Build & Install", code: "./gradlew build\n./gradlew installDebug" },
    { num: "4", title: "Build Release APK", code: "./gradlew assembleRelease" },
  ];

  return (
    <div
      className="min-h-screen text-white"
      style={{ fontFamily: "'Inter', sans-serif", backgroundColor: "#06040f" }}
    >
      <style>{`
        @keyframes wave {
          from { transform: scaleY(0.3); }
          to   { transform: scaleY(1); }
        }
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-20px) rotate(5deg); }
        }
        @keyframes glow-pulse {
          0%, 100% { opacity: 0.4; }
          50% { opacity: 0.8; }
        }
        @keyframes slide-up {
          from { opacity: 0; transform: translateY(30px); }
          to   { opacity: 1; transform: translateY(0); }
        }
        .animate-float { animation: float 6s ease-in-out infinite; }
        .animate-glow-pulse { animation: glow-pulse 3s ease-in-out infinite; }
        .animate-slide-up { animation: slide-up 0.7s ease-out forwards; }
        .delay-100 { animation-delay: 0.1s; opacity: 0; }
        .delay-200 { animation-delay: 0.2s; opacity: 0; }
        .delay-300 { animation-delay: 0.3s; opacity: 0; }
        .delay-400 { animation-delay: 0.4s; opacity: 0; }
      `}</style>

      <Navbar />

      {/* ===== HERO ===== */}
      <section
        ref={heroRef}
        className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20"
      >
        {/* Background image */}
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{ backgroundImage: "url('/hero-bg.jpg')" }}
        />
        {/* Dark overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/60 to-[#06040f]" />

        {/* Glow orbs */}
        <div className="absolute top-1/3 left-1/4 w-72 h-72 rounded-full bg-purple-600/30 blur-[80px] animate-glow-pulse pointer-events-none" />
        <div className="absolute bottom-1/3 right-1/4 w-60 h-60 rounded-full bg-blue-600/20 blur-[80px] animate-glow-pulse pointer-events-none" style={{ animationDelay: "1.5s" }} />

        {/* Floating TV emoji */}
        <div className="absolute right-10 top-1/3 text-6xl opacity-20 animate-float hidden lg:block pointer-events-none select-none">
          📺
        </div>
        <div className="absolute left-10 bottom-1/3 text-5xl opacity-15 animate-float hidden lg:block pointer-events-none select-none" style={{ animationDelay: "2s" }}>
          🎵
        </div>

        <div className="relative z-10 text-center max-w-4xl mx-auto px-6">
          {/* Badge */}
          <div className="animate-slide-up inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-purple-500/40 bg-purple-500/10 text-purple-300 text-sm font-medium mb-6">
            <span className="w-2 h-2 rounded-full bg-purple-400 animate-pulse" />
            🚀 In Active Development
          </div>

          {/* Title */}
          <h1 className="animate-slide-up delay-100 text-5xl md:text-7xl font-black leading-tight tracking-tight mb-4">
            <span className="text-white">Echo </span>
            <span
              className="bg-clip-text text-transparent"
              style={{
                backgroundImage: "linear-gradient(135deg, #a855f7 0%, #6366f1 50%, #3b82f6 100%)",
              }}
            >
              Android TV
            </span>
          </h1>

          {/* Subtitle */}
          <p className="animate-slide-up delay-200 text-white/60 text-xl md:text-2xl font-light mb-4 max-w-2xl mx-auto leading-relaxed">
            A powerful music player for <strong className="text-white/80">Android TV</strong> — built on Echo's extension architecture with full remote control support.
          </p>

          {/* Live wave indicator */}
          <div className="animate-slide-up delay-300 flex items-center justify-center gap-2 mb-10 text-purple-400 text-sm">
            <WaveBars count={6} color="#a855f7" />
            <span>Leanback UI · D-Pad Ready · Extension Powered</span>
            <WaveBars count={6} color="#a855f7" />
          </div>

          {/* CTA buttons */}
          <div className="animate-slide-up delay-400 flex flex-wrap items-center justify-center gap-4">
            <a
              href="https://github.com/masrafi17/echo-android-tv"
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-2 px-7 py-3.5 rounded-full font-semibold text-white transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:shadow-purple-600/40"
              style={{ background: "linear-gradient(135deg, #9333ea, #4f46e5)" }}
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2C6.477 2 2 6.477 2 12c0 4.418 2.865 8.166 6.839 9.489.5.092.682-.217.682-.482 0-.237-.008-.866-.013-1.7-2.782.603-3.369-1.34-3.369-1.34-.454-1.156-1.11-1.464-1.11-1.464-.908-.62.069-.608.069-.608 1.003.07 1.531 1.03 1.531 1.03.892 1.529 2.341 1.087 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.11-4.555-4.943 0-1.091.39-1.984 1.029-2.683-.103-.253-.446-1.27.098-2.647 0 0 .84-.269 2.75 1.025A9.578 9.578 0 0 1 12 6.836c.85.004 1.705.115 2.504.337 1.909-1.294 2.747-1.025 2.747-1.025.546 1.377.203 2.394.1 2.647.64.699 1.028 1.592 1.028 2.683 0 3.842-2.339 4.687-4.566 4.935.359.309.678.919.678 1.852 0 1.336-.012 2.415-.012 2.743 0 .267.18.578.688.48C19.138 20.163 22 16.418 22 12c0-5.523-4.477-10-10-10z" />
              </svg>
              View on GitHub
            </a>
            <a
              href="#features"
              className="flex items-center gap-2 px-7 py-3.5 rounded-full font-semibold text-white/80 border border-white/20 hover:border-purple-500/60 hover:text-white hover:bg-white/5 transition-all duration-300"
            >
              Explore Features ↓
            </a>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white/30 text-xs">
          <span>scroll</span>
          <div className="w-px h-10 bg-gradient-to-b from-white/20 to-transparent" />
        </div>
      </section>

      {/* ===== STATS ===== */}
      <section className="py-14 px-6">
        <div className="max-w-4xl mx-auto flex flex-wrap justify-center gap-4">
          <StatCard num="5+" icon="✅" label="Features Ready" />
          <StatCard num="MVVM" icon="🏗️" label="Architecture" />
          <StatCard num="API 31+" icon="🤖" label="Min SDK" />
          <StatCard num="MIT" icon="📄" label="License" />
          <StatCard num="Kotlin" icon="🟣" label="Language" />
        </div>
      </section>

      {/* ===== FEATURES ===== */}
      <section id="features" className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-14">
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4">
              Features
            </h2>
            <p className="text-white/50 text-lg max-w-xl mx-auto">
              Everything you need for a premium TV music experience — built and planned.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-2 gap-4">
            {features.map((f, i) => (
              <FeatureCard key={i} {...f} />
            ))}
          </div>
        </div>
      </section>

      {/* ===== TECH STACK ===== */}
      <section id="tech" className="py-20 px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-14">
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4">
              Tech Stack
            </h2>
            <p className="text-white/50 text-lg">
              Built with modern Android development tools and best practices.
            </p>
          </div>
          {/* Architecture diagram */}
          <div className="rounded-3xl border border-white/10 bg-white/5 backdrop-blur-sm p-8 mb-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
              <div className="rounded-2xl bg-purple-600/20 border border-purple-500/30 p-5">
                <div className="text-3xl mb-2">🖼️</div>
                <div className="text-white font-semibold mb-1">UI Layer</div>
                <div className="text-white/50 text-sm">Leanback Fragments<br/>BrowseFragment<br/>PlaybackOverlayFragment<br/>DetailsFragment</div>
              </div>
              <div className="rounded-2xl bg-indigo-600/20 border border-indigo-500/30 p-5">
                <div className="text-3xl mb-2">⚙️</div>
                <div className="text-white font-semibold mb-1">ViewModel Layer</div>
                <div className="text-white/50 text-sm">MVVM Pattern<br/>LiveData / StateFlow<br/>Clean Architecture<br/>UseCases</div>
              </div>
              <div className="rounded-2xl bg-blue-600/20 border border-blue-500/30 p-5">
                <div className="text-3xl mb-2">🔌</div>
                <div className="text-white font-semibold mb-1">Data Layer</div>
                <div className="text-white/50 text-sm">Echo Extensions<br/>Dynamic Sources<br/>Repositories<br/>Streaming Services</div>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap justify-center gap-3">
            {techStack.map((t, i) => (
              <TechBadge key={i} {...t} />
            ))}
          </div>
        </div>
      </section>

      {/* ===== PROJECT STRUCTURE ===== */}
      <section className="py-20 px-6">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-14">
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4">
              Project Structure
            </h2>
            <p className="text-white/50 text-lg">Clean and organized codebase.</p>
          </div>
          <div className="rounded-2xl border border-white/10 bg-black/40 backdrop-blur-sm p-6">
            <pre className="text-sm font-mono text-white/70 leading-7 overflow-x-auto">
{`echo-android-tv/
├── 📁 app/
│   ├── 📁 src/
│   │   ├── 📁 main/
│   │   │   ├── 📁 java/com/masrafi17/echotv/
│   │   │   ├── 📁 res/
│   │   │   └── 📄 AndroidManifest.xml
│   │   └── 📁 test/
│   ├── 📄 build.gradle
│   └── 📄 proguard-rules.pro
├── 📄 build.gradle
├── 📄 settings.gradle
├── 📄 .gitignore
└── 📄 README.md`}
            </pre>
          </div>
        </div>
      </section>

      {/* ===== INSTALL ===== */}
      <section id="install" className="py-20 px-6">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-14">
            <h2 className="text-4xl md:text-5xl font-black text-white mb-4">
              Get Started
            </h2>
            <p className="text-white/50 text-lg">
              Clone, build, and run in minutes.
            </p>
          </div>
          <div className="flex flex-col gap-4">
            {steps.map((s) => (
              <StepCard key={s.num} {...s} />
            ))}
          </div>
          {/* Prerequisites */}
          <div className="mt-8 rounded-2xl border border-yellow-500/20 bg-yellow-500/5 p-6">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-xl">⚠️</span>
              <span className="text-yellow-300 font-semibold">Prerequisites</span>
            </div>
            <ul className="text-white/60 text-sm space-y-1.5">
              <li>✔ Android Studio Giraffe or newer</li>
              <li>✔ Android SDK API 31+</li>
              <li>✔ Kotlin 1.9+</li>
              <li>✔ A physical Android TV or emulator</li>
            </ul>
          </div>
        </div>
      </section>

      {/* ===== CTA BANNER ===== */}
      <section className="py-24 px-6">
        <div className="max-w-4xl mx-auto">
          <div
            className="rounded-3xl p-12 text-center relative overflow-hidden"
            style={{
              background: "linear-gradient(135deg, rgba(147,51,234,0.3) 0%, rgba(79,70,229,0.3) 50%, rgba(59,130,246,0.3) 100%)",
              border: "1px solid rgba(147,51,234,0.3)",
            }}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-purple-600/10 to-blue-600/10 pointer-events-none" />
            <div className="relative z-10">
              <div className="text-5xl mb-4">🎵</div>
              <h2 className="text-3xl md:text-4xl font-black text-white mb-4">
                Contribute to Echo TV
              </h2>
              <p className="text-white/60 text-lg mb-8 max-w-xl mx-auto">
                This project is open-source and welcomes contributions. Star the repo, open issues, or submit a Pull Request!
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <a
                  href="https://github.com/masrafi17/echo-android-tv"
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-2 px-7 py-3.5 rounded-full font-semibold text-white transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:shadow-purple-600/40"
                  style={{ background: "linear-gradient(135deg, #9333ea, #4f46e5)" }}
                >
                  ⭐ Star on GitHub
                </a>
                <a
                  href="https://github.com/masrafi17/echo-android-tv/issues"
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-2 px-7 py-3.5 rounded-full font-semibold text-white/80 border border-white/20 hover:border-purple-500/60 hover:text-white hover:bg-white/5 transition-all duration-300"
                >
                  🐛 Open an Issue
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== FOOTER ===== */}
      <footer className="border-t border-white/10 py-10 px-6">
        <div className="max-w-4xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-white/40 text-sm">
          <div className="flex items-center gap-2">
            <span>🎵</span>
            <span className="font-semibold text-white/60">Echo Android TV</span>
            <span>— MIT License</span>
          </div>
          <div className="flex items-center gap-2">
            Built with ❤️ by{" "}
            <a
              href="https://github.com/masrafi17"
              target="_blank"
              rel="noreferrer"
              className="text-purple-400 hover:text-purple-300 transition-colors font-medium"
            >
              @masrafi17
            </a>
          </div>
          <div className="flex items-center gap-4">
            <a
              href="https://github.com/masrafi17/echo-android-tv"
              target="_blank"
              rel="noreferrer"
              className="hover:text-white transition-colors"
            >
              GitHub ↗
            </a>
            <a
              href="https://github.com/masrafi17/echo-android-tv/blob/main/README.md"
              target="_blank"
              rel="noreferrer"
              className="hover:text-white transition-colors"
            >
              README ↗
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
