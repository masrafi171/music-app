export interface LyricLine {
  time: number; // seconds
  text: string;
}

export interface LyricsResult {
  synced: LyricLine[] | null;
  plain: string | null;
}

function parseLRC(lrc: string): LyricLine[] {
  const lines = lrc.split("\n");
  const result: LyricLine[] = [];
  const timeRegex = /\[(\d{2}):(\d{2})\.(\d{2,3})\]/g;

  for (const line of lines) {
    const matches = [...line.matchAll(timeRegex)];
    if (matches.length === 0) continue;

    const text = line.replace(timeRegex, "").trim();

    for (const match of matches) {
      const minutes = parseInt(match[1]);
      const seconds = parseInt(match[2]);
      const centiseconds = parseInt(match[3]);
      const time = minutes * 60 + seconds + centiseconds / (match[3].length === 3 ? 1000 : 100);
      result.push({ time, text });
    }
  }

  return result.sort((a, b) => a.time - b.time);
}

export async function fetchLyrics(
  trackName: string,
  artistName: string,
  albumName?: string,
  duration?: number
): Promise<LyricsResult> {
  try {
    // Try direct get first
    const params = new URLSearchParams({
      track_name: trackName,
      artist_name: artistName,
    });
    if (albumName) params.append("album_name", albumName);
    if (duration) params.append("duration", duration.toString());

    const getResponse = await fetch(
      `https://lrclib.net/api/get?${params.toString()}`,
      {
        headers: { "Lrclib-Client": "EchoTV v1.0 (https://echotv.app)" },
      }
    );

    if (getResponse.ok) {
      const data = await getResponse.json();
      return {
        synced: data.syncedLyrics ? parseLRC(data.syncedLyrics) : null,
        plain: data.plainLyrics || null,
      };
    }

    // Fallback to search
    const searchParams = new URLSearchParams({ q: `${trackName} ${artistName}` });
    const searchResponse = await fetch(
      `https://lrclib.net/api/search?${searchParams.toString()}`,
      {
        headers: { "Lrclib-Client": "EchoTV v1.0 (https://echotv.app)" },
      }
    );

    if (searchResponse.ok) {
      const results = await searchResponse.json();
      // Prefer results with synced lyrics
      const withSynced = results.find((r: any) => r.syncedLyrics);
      const best = withSynced || results[0];
      if (best) {
        return {
          synced: best.syncedLyrics ? parseLRC(best.syncedLyrics) : null,
          plain: best.plainLyrics || null,
        };
      }
    }
  } catch (err) {
    console.error("Lyrics fetch error:", err);
  }

  return { synced: null, plain: null };
}
