import { Song } from "../data/songs";

interface SongListProps {
  songs: Song[];
  currentSong: Song | null;
  isPlaying: boolean;
  onSelect: (song: Song) => void;
}

function formatDuration(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

export default function SongList({
  songs,
  currentSong,
  isPlaying,
  onSelect,
}: SongListProps) {
  return (
    <div className="flex flex-col h-full overflow-hidden">
      <div className="px-4 py-3 border-b border-white/10">
        <h2 className="text-white/60 text-xs font-semibold uppercase tracking-widest">
          Songs — {songs.length}
        </h2>
      </div>
      <div className="flex-1 overflow-y-auto scrollbar-hide">
        {songs.map((song, index) => {
          const isActive = currentSong?.id === song.id;
          return (
            <div
              key={song.id}
              onClick={() => onSelect(song)}
              className={`flex items-center gap-3 px-4 py-3 cursor-pointer group transition-all duration-200 ${
                isActive
                  ? "bg-white/15"
                  : "hover:bg-white/8"
              }`}
            >
              {/* Index / Playing indicator */}
              <div className="w-6 flex-shrink-0 flex items-center justify-center">
                {isActive && isPlaying ? (
                  <div className="flex items-end gap-[2px] h-4">
                    <div className="w-[3px] bg-[#fc3c44] rounded-full animate-[bounce_0.8s_ease-in-out_infinite]" style={{ height: "60%", animationDelay: "0ms" }} />
                    <div className="w-[3px] bg-[#fc3c44] rounded-full animate-[bounce_0.8s_ease-in-out_infinite]" style={{ height: "100%", animationDelay: "150ms" }} />
                    <div className="w-[3px] bg-[#fc3c44] rounded-full animate-[bounce_0.8s_ease-in-out_infinite]" style={{ height: "40%", animationDelay: "300ms" }} />
                  </div>
                ) : (
                  <span className={`text-xs font-medium ${isActive ? "text-[#fc3c44]" : "text-white/40 group-hover:text-white/70"}`}>
                    {index + 1}
                  </span>
                )}
              </div>

              {/* Thumbnail */}
              <div className="relative w-10 h-10 rounded-md overflow-hidden flex-shrink-0">
                <img
                  src={song.thumbnail}
                  alt={song.title}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = `https://i.ytimg.com/vi/${song.videoId}/hqdefault.jpg`;
                  }}
                />
                {isActive && (
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                    <div className="w-2 h-2 rounded-full bg-white" />
                  </div>
                )}
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <p className={`text-sm font-semibold truncate leading-tight ${isActive ? "text-[#fc3c44]" : "text-white group-hover:text-white"}`}>
                  {song.title}
                </p>
                <p className="text-xs text-white/50 truncate mt-0.5">{song.artist}</p>
              </div>

              {/* Duration */}
              <div className="flex-shrink-0">
                <span className="text-xs text-white/40">{formatDuration(song.duration)}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
