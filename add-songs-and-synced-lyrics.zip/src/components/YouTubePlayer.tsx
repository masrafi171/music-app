import { useEffect, useRef, forwardRef, useImperativeHandle } from "react";

interface YouTubePlayerProps {
  videoId: string;
  onReady?: () => void;
  onStateChange?: (state: number) => void;
  onTimeUpdate?: (time: number) => void;
  onDuration?: (duration: number) => void;
  onError?: () => void;
}

export interface YouTubePlayerHandle {
  play: () => void;
  pause: () => void;
  seekTo: (seconds: number) => void;
  setVolume: (vol: number) => void;
  getCurrentTime: () => number;
  getDuration: () => number;
}

declare global {
  interface Window {
    YT: any;
    onYouTubeIframeAPIReady: () => void;
  }
}

let ytApiReady = false;
let ytApiCallbacks: (() => void)[] = [];

function loadYTApi(): Promise<void> {
  return new Promise((resolve) => {
    if (ytApiReady) {
      resolve();
      return;
    }
    ytApiCallbacks.push(resolve);
    if (!document.getElementById("yt-api-script")) {
      const script = document.createElement("script");
      script.id = "yt-api-script";
      script.src = "https://www.youtube.com/iframe_api";
      document.head.appendChild(script);
      window.onYouTubeIframeAPIReady = () => {
        ytApiReady = true;
        ytApiCallbacks.forEach((cb) => cb());
        ytApiCallbacks = [];
      };
    }
  });
}

const YouTubePlayer = forwardRef<YouTubePlayerHandle, YouTubePlayerProps>(
  ({ videoId, onReady, onStateChange, onTimeUpdate, onDuration, onError }, ref) => {
    const containerRef = useRef<HTMLDivElement>(null);
    const playerRef = useRef<any>(null);
    const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
    const currentVideoRef = useRef<string>("");

    useImperativeHandle(ref, () => ({
      play: () => playerRef.current?.playVideo(),
      pause: () => playerRef.current?.pauseVideo(),
      seekTo: (s: number) => playerRef.current?.seekTo(s, true),
      setVolume: (v: number) => playerRef.current?.setVolume(v),
      getCurrentTime: () => playerRef.current?.getCurrentTime() ?? 0,
      getDuration: () => playerRef.current?.getDuration() ?? 0,
    }));

    useEffect(() => {
      let cancelled = false;
      loadYTApi().then(() => {
        if (cancelled || !containerRef.current) return;
        const div = document.createElement("div");
        containerRef.current.appendChild(div);

        playerRef.current = new window.YT.Player(div, {
          videoId,
          playerVars: {
            autoplay: 1,
            controls: 0,
            rel: 0,
            modestbranding: 1,
            iv_load_policy: 3,
            playsinline: 1,
          },
          events: {
            onReady: () => {
              onReady?.();
              onDuration?.(playerRef.current?.getDuration() ?? 0);
              currentVideoRef.current = videoId;
            },
            onStateChange: (e: any) => {
              onStateChange?.(e.data);
              if (e.data === 1) {
                // playing
                timerRef.current = setInterval(() => {
                  const t = playerRef.current?.getCurrentTime() ?? 0;
                  const d = playerRef.current?.getDuration() ?? 0;
                  onTimeUpdate?.(t);
                  onDuration?.(d);
                }, 250);
              } else {
                if (timerRef.current) clearInterval(timerRef.current);
              }
            },
            onError: () => onError?.(),
          },
        });
      });

      return () => {
        cancelled = true;
        if (timerRef.current) clearInterval(timerRef.current);
        try {
          playerRef.current?.destroy();
        } catch {}
      };
    }, []);

    // Handle videoId changes
    useEffect(() => {
      if (!playerRef.current || !ytApiReady) return;
      if (currentVideoRef.current === videoId) return;
      currentVideoRef.current = videoId;
      playerRef.current.loadVideoById(videoId);
    }, [videoId]);

    return (
      <div
        ref={containerRef}
        className="w-0 h-0 overflow-hidden absolute"
        style={{ pointerEvents: "none" }}
      />
    );
  }
);

YouTubePlayer.displayName = "YouTubePlayer";
export default YouTubePlayer;
