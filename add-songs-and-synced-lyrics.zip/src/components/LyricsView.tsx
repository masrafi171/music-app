import { useEffect, useRef, useMemo } from "react";
import { LyricLine } from "../services/lyricsService";

interface LyricsViewProps {
  lyrics: LyricLine[];
  plainLyrics: string | null;
  currentTime: number;
  isVisible: boolean;
}

export default function LyricsView({
  lyrics,
  plainLyrics,
  currentTime,
  isVisible,
}: LyricsViewProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const lineRefs = useRef<(HTMLDivElement | null)[]>([]);

  const activeIndex = useMemo(() => {
    if (!lyrics.length) return -1;
    let idx = -1;
    for (let i = 0; i < lyrics.length; i++) {
      if (lyrics[i].time <= currentTime + 0.3) {
        idx = i;
      } else {
        break;
      }
    }
    return idx;
  }, [lyrics, currentTime]);

  useEffect(() => {
    const el = lineRefs.current[activeIndex];
    if (el && containerRef.current) {
      el.scrollIntoView({
        behavior: "smooth",
        block: "center",
      });
    }
  }, [activeIndex]);

  if (!isVisible) return null;

  if (!lyrics.length && !plainLyrics) {
    return (
      <div className="flex flex-col items-center justify-center h-full gap-4 px-6">
        <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center">
          <svg viewBox="0 0 24 24" fill="currentColor" className="w-7 h-7 text-white/20">
            <path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/>
          </svg>
        </div>
        <p className="text-white/30 text-sm font-medium text-center">No lyrics available for this song</p>
      </div>
    );
  }

  // Plain lyrics fallback
  if (!lyrics.length && plainLyrics) {
    return (
      <div
        ref={containerRef}
        className="h-full overflow-y-auto px-8 py-6 scrollbar-hide"
      >
        <div className="max-w-lg space-y-0.5">
          {plainLyrics.split("\n").map((line, i) => (
            <p
              key={i}
              className={`leading-snug py-1 transition-all duration-300 ${
                line.trim() === ""
                  ? "h-5"
                  : "text-white/65 text-2xl font-bold"
              }`}
            >
              {line || ""}
            </p>
          ))}
          <div className="h-20" />
        </div>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="h-full overflow-y-auto scrollbar-hide relative"
      style={{
        WebkitMaskImage: "linear-gradient(to bottom, transparent 0%, black 12%, black 88%, transparent 100%)",
        maskImage: "linear-gradient(to bottom, transparent 0%, black 12%, black 88%, transparent 100%)",
      }}
    >
      <div className="px-8 py-4">
        {/* Top padding for centering */}
        <div className="h-36" />

        {lyrics.map((line, i) => {
          const isActive = i === activeIndex;
          const dist = i - activeIndex;
          const isNearBefore = dist >= -3 && dist < 0;
          const isNearAfter = dist > 0 && dist <= 3;
          const isFarBefore = dist < -3;
          const isFarAfter = dist > 3;

          if (line.text === "") {
            return <div key={i} className="h-6" />;
          }

          let opacity = 1;
          let scale = 1;
          let blur = 0;

          if (isActive) {
            opacity = 1;
            scale = 1.03;
            blur = 0;
          } else if (isNearBefore) {
            opacity = 0.35 + (dist + 3) * 0.1;
            scale = 0.99;
            blur = 0;
          } else if (isFarBefore) {
            opacity = 0.15;
            scale = 0.97;
            blur = 0;
          } else if (isNearAfter) {
            opacity = 0.25 + (3 - dist) * 0.05;
            scale = 0.99;
            blur = 0;
          } else if (isFarAfter) {
            opacity = 0.12;
            scale = 0.97;
            blur = 0;
          }

          return (
            <div
              key={i}
              ref={(el) => { lineRefs.current[i] = el; }}
              className="transition-all duration-500 ease-out"
              style={{
                opacity,
                transform: `scale(${scale})`,
                transformOrigin: "left center",
                filter: blur > 0 ? `blur(${blur}px)` : undefined,
              }}
            >
              <p
                className={`text-2xl md:text-3xl font-bold leading-snug py-2 cursor-default select-none transition-all duration-500 ${
                  isActive ? "text-white drop-shadow-[0_0_20px_rgba(255,255,255,0.3)]" : "text-white"
                }`}
              >
                {line.text}
              </p>
            </div>
          );
        })}

        {/* Bottom padding */}
        <div className="h-40" />
      </div>
    </div>
  );
}
