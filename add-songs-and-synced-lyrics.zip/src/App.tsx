import { useState, useRef, useEffect, useCallback } from "react";
import { SONGS, Song } from "./data/songs";
import { fetchLyrics, LyricLine } from "./services/lyricsService";
import YouTubePlayer, { YouTubePlayerHandle } from "./components/YouTubePlayer";
import LyricsView from "./components/LyricsView";
import SongList from "./components/SongList";
import PlayerControls from "./components/PlayerControls";

type RepeatMode = "none" | "one" | "all";
type MobileView = "player" | "songs" | "lyrics";

const BG_COLORS: Record<string, string> = {
  "1": "#0d1b2e", "2": "#1e0d1e", "3": "#1e0a0a", "4": "#0a1e1e",
  "5": "#1e1505", "6": "#100a1e", "7": "#0a0f1e", "8": "#1e0f0a",
  "9": "#0a1e10", "10": "#1e0a12", "11": "#150a1e", "12": "#0a1510",
  "13": "#1e100a", "14": "#0a0a1e", "15": "#0f1e0a", "16": "#1e0f18",
  "17": "#0a1e18", "18": "#1e0a10", "19": "#120a1e", "20": "#0a1218",
};

export default function App() {
  const [currentSong, setCurrentSong] = useState<Song>(SONGS[0]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(80);
  const [isShuffled, setIsShuffled] = useState(false);
  const [repeatMode, setRepeatMode] = useState<RepeatMode>("none");
  const [lyrics, setLyrics] = useState<LyricLine[]>([]);
  const [plainLyrics, setPlainLyrics] = useState<string | null>(null);
  const [lyricsLoading, setLyricsLoading] = useState(false);
  const [showLyrics, setShowLyrics] = useState(true);
  const [mobileView, setMobileView] = useState<MobileView>("player");
  const [shuffleOrder, setShuffleOrder] = useState<number[]>([]);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [imgError, setImgError] = useState(false);

  const playerRef = useRef<YouTubePlayerHandle>(null);

  const currentIndex = SONGS.findIndex((s) => s.id === currentSong.id);
  const bgColor = BG_COLORS[currentSong.id] || "#0f0f1a";

  // Load lyrics whenever song changes
  useEffect(() => {
    setLyrics([]);
    setPlainLyrics(null);
    setLyricsLoading(true);
    setImgError(false);

    const trackName = currentSong.lrclibTrack || currentSong.title;
    const artistName = currentSong.lrclibArtist || currentSong.artist;

    fetchLyrics(trackName, artistName, currentSong.album, currentSong.duration)
      .then((result) => {
        setLyrics(result.synced || []);
        setPlainLyrics(result.plain);
      })
      .finally(() => setLyricsLoading(false));
  }, [currentSong.id]);

  // Generate shuffle order
  useEffect(() => {
    if (isShuffled) {
      const indices = SONGS.map((_, i) => i).filter((i) => i !== currentIndex);
      for (let i = indices.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [indices[i], indices[j]] = [indices[j], indices[i]];
      }
      setShuffleOrder([currentIndex, ...indices]);
    }
  }, [isShuffled, currentIndex]);

  const getNextIndex = useCallback(() => {
    if (isShuffled && shuffleOrder.length > 0) {
      const pos = shuffleOrder.indexOf(currentIndex);
      return shuffleOrder[(pos + 1) % shuffleOrder.length];
    }
    return (currentIndex + 1) % SONGS.length;
  }, [currentIndex, isShuffled, shuffleOrder]);

  const getPrevIndex = useCallback(() => {
    if (isShuffled && shuffleOrder.length > 0) {
      const pos = shuffleOrder.indexOf(currentIndex);
      return shuffleOrder[(pos - 1 + shuffleOrder.length) % shuffleOrder.length];
    }
    return (currentIndex - 1 + SONGS.length) % SONGS.length;
  }, [currentIndex, isShuffled, shuffleOrder]);

  const handleSongSelect = (song: Song) => {
    setCurrentSong(song);
    setIsPlaying(true);
    setCurrentTime(0);
    if (window.innerWidth < 768) setMobileView("player");
  };

  const handleNext = useCallback(() => {
    setCurrentSong(SONGS[getNextIndex()]);
    setIsPlaying(true);
    setCurrentTime(0);
  }, [getNextIndex]);

  const handlePrev = useCallback(() => {
    if (currentTime > 3) {
      playerRef.current?.seekTo(0);
      setCurrentTime(0);
      return;
    }
    setCurrentSong(SONGS[getPrevIndex()]);
    setIsPlaying(true);
    setCurrentTime(0);
  }, [currentTime, getPrevIndex]);

  const handleStateChange = (state: number) => {
    if (state === 1) setIsPlaying(true);
    else if (state === 2) setIsPlaying(false);
    else if (state === 0) {
      if (repeatMode === "one") {
        playerRef.current?.seekTo(0);
        playerRef.current?.play();
      } else {
        handleNext();
      }
    }
  };

  const handlePlayPause = () => {
    if (isPlaying) playerRef.current?.pause();
    else playerRef.current?.play();
  };

  const handleRepeat = () => {
    setRepeatMode((m) => m === "none" ? "all" : m === "all" ? "one" : "none");
  };

  const handleVolumeChange = (vol: number) => {
    setVolume(vol);
    playerRef.current?.setVolume(vol);
  };

  const handleSeek = (time: number) => {
    playerRef.current?.seekTo(time);
    setCurrentTime(time);
  };

  const handleReady = () => {
    playerRef.current?.setVolume(volume);
    playerRef.current?.play();
    setIsPlaying(true);
  };

  const thumbnailUrl = imgError
    ? `https://i.ytimg.com/vi/${currentSong.videoId}/hqdefault.jpg`
    : `https://i.ytimg.com/vi/${currentSong.videoId}/maxresdefault.jpg`;

  return (
    <div
      className="h-screen flex flex-col overflow-hidden transition-colors duration-1000"
      style={{
        background: `radial-gradient(ellipse 80% 60% at 0% 0%, ${bgColor}ee 0%, #08080f 55%, #030305 100%)`,
      }}
    >
      {/* Hidden YouTube Player */}
      <YouTubePlayer
        ref={playerRef}
        videoId={currentSong.videoId}
        onReady={handleReady}
        onStateChange={handleStateChange}
        onTimeUpdate={setCurrentTime}
        onDuration={setDuration}
        onError={handleNext}
      />

      {/* Top Header */}
      <header className="flex-shrink-0 flex items-center justify-between px-5 py-3 border-b border-white/[0.07]">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setSidebarOpen((v) => !v)}
            className="p-1.5 rounded-lg text-white/40 hover:text-white hover:bg-white/8 transition-all"
          >
            <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
              <path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"/>
            </svg>
          </button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#fc3c44] via-[#d42f37] to-[#a01f26] flex items-center justify-center shadow-lg shadow-[#fc3c44]/20">
              <svg viewBox="0 0 24 24" fill="white" className="w-4 h-4">
                <path d="M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"/>
              </svg>
            </div>
            <div>
              <span className="text-white font-bold text-sm tracking-tight">Echo TV</span>
              <p className="text-white/30 text-[10px] leading-none">Music Player</p>
            </div>
          </div>
        </div>

        {/* Mobile tab switcher */}
        <nav className="flex md:hidden items-center gap-0.5 bg-white/8 p-1 rounded-xl">
          {(["player", "songs", "lyrics"] as MobileView[]).map((v) => (
            <button
              key={v}
              onClick={() => setMobileView(v)}
              className={`px-3 py-1.5 rounded-lg text-[11px] font-semibold capitalize transition-all ${
                mobileView === v
                  ? "bg-white text-black shadow"
                  : "text-white/50 hover:text-white"
              }`}
            >
              {v}
            </button>
          ))}
        </nav>

        {/* Desktop info */}
        <div className="hidden md:flex items-center gap-3">
          <span className="text-white/25 text-xs">
            {SONGS.length} songs • YouTube Music
          </span>
          <button
            onClick={() => setShowLyrics((v) => !v)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              showLyrics
                ? "bg-[#fc3c44]/15 text-[#fc3c44] border border-[#fc3c44]/20"
                : "bg-white/5 text-white/40 hover:text-white border border-white/10"
            }`}
          >
            <svg viewBox="0 0 24 24" fill="currentColor" className="w-3.5 h-3.5">
              <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-2 12H6v-2h12v2zm0-3H6V9h12v2zm0-3H6V6h12v2z"/>
            </svg>
            Lyrics
          </button>
        </div>
      </header>

      {/* Main Body */}
      <div className="flex-1 flex overflow-hidden min-h-0">

        {/* === SIDEBAR: Song List === */}
        <aside
          className={`hidden md:flex flex-col border-r border-white/[0.07] transition-all duration-300 overflow-hidden flex-shrink-0 ${
            sidebarOpen ? "w-[260px]" : "w-0"
          }`}
        >
          <SongList
            songs={SONGS}
            currentSong={currentSong}
            isPlaying={isPlaying}
            onSelect={handleSongSelect}
          />
        </aside>

        {/* === CENTER: Player === */}
        <main
          className={`flex-shrink-0 flex flex-col items-center justify-between py-8 px-6 overflow-hidden transition-all
            ${mobileView !== "songs" ? "flex" : "hidden md:flex"}
            w-full md:w-[320px] lg:w-[360px]
          `}
        >
          {/* Album art */}
          <div className="flex-1 flex items-center justify-center w-full min-h-0">
            <div
              className={`relative rounded-2xl overflow-hidden flex-shrink-0 transition-all duration-700 ${
                isPlaying ? "shadow-2xl scale-100" : "shadow-lg scale-95"
              }`}
              style={{
                width: "min(260px, 100%)",
                aspectRatio: "1",
                boxShadow: isPlaying
                  ? `0 30px 90px ${bgColor}bb, 0 0 60px rgba(0,0,0,0.7)`
                  : "0 10px 40px rgba(0,0,0,0.5)",
              }}
            >
              <img
                src={thumbnailUrl}
                alt={currentSong.title}
                className="w-full h-full object-cover"
                onError={() => setImgError(true)}
              />
              {/* Glass sheen */}
              <div
                className="absolute inset-0"
                style={{
                  background:
                    "linear-gradient(135deg, rgba(255,255,255,0.06) 0%, transparent 40%, rgba(0,0,0,0.15) 100%)",
                }}
              />
              {/* Now playing bars */}
              {isPlaying && (
                <div className="absolute bottom-2.5 right-2.5 flex items-end gap-[2.5px]">
                  {[1, 0.6, 0.9, 0.5, 0.8].map((h, i) => (
                    <div
                      key={i}
                      className="w-[3px] bg-white/70 rounded-full"
                      style={{
                        height: `${14 * h}px`,
                        animation: `soundbar ${0.8 + i * 0.1}s ease-in-out infinite`,
                        animationDelay: `${i * 0.12}s`,
                      }}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Controls */}
          <div className="w-full max-w-[300px] flex-shrink-0 mt-6">
            <PlayerControls
              title={currentSong.title}
              artist={currentSong.artist}
              album={currentSong.album}
              currentTime={currentTime}
              duration={duration || currentSong.duration}
              isPlaying={isPlaying}
              isShuffled={isShuffled}
              repeatMode={repeatMode}
              volume={volume}
              onPlayPause={handlePlayPause}
              onNext={handleNext}
              onPrev={handlePrev}
              onSeek={handleSeek}
              onShuffle={() => setIsShuffled((v) => !v)}
              onRepeat={handleRepeat}
              onVolumeChange={handleVolumeChange}
              onLyricsToggle={() => {
                setShowLyrics((v) => !v);
                if (window.innerWidth < 768) setMobileView("lyrics");
              }}
              lyricsActive={showLyrics}
            />
          </div>
        </main>

        {/* === RIGHT: Lyrics Panel === */}
        {(showLyrics || mobileView === "lyrics") && (
          <section
            className={`flex-1 flex flex-col min-w-0 border-l border-white/[0.07] relative overflow-hidden
              ${mobileView === "lyrics" ? "flex" : mobileView === "songs" ? "hidden md:flex" : "hidden md:flex"}
            `}
          >
            {/* Lyrics header bar */}
            <div className="flex-shrink-0 flex items-center justify-between px-6 pt-5 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-1 h-5 rounded-full bg-[#fc3c44]" />
                <span className="text-white/50 text-[11px] font-bold uppercase tracking-widest">
                  {lyrics.length > 0 ? "Synced Lyrics" : plainLyrics ? "Lyrics" : "Lyrics"}
                </span>
                {lyrics.length > 0 && !lyricsLoading && (
                  <div className="flex items-center gap-1 bg-[#fc3c44]/10 border border-[#fc3c44]/20 px-2 py-0.5 rounded-full">
                    <div className="w-1.5 h-1.5 rounded-full bg-[#fc3c44] animate-pulse" />
                    <span className="text-[#fc3c44] text-[10px] font-bold">LIVE</span>
                  </div>
                )}
              </div>
              {lyricsLoading && (
                <div className="flex items-center gap-1.5 text-white/25 text-xs">
                  <div className="w-3 h-3 border border-white/25 border-t-white/60 rounded-full animate-spin" />
                  <span>Loading...</span>
                </div>
              )}
            </div>

            {/* Lyrics content */}
            <div className="flex-1 min-h-0 overflow-hidden">
              {lyricsLoading ? (
                <div className="flex items-center justify-center h-full">
                  <div className="flex flex-col items-center gap-4">
                    <div className="w-10 h-10 border-2 border-white/10 border-t-white/50 rounded-full animate-spin" />
                    <p className="text-white/25 text-sm">Fetching lyrics...</p>
                  </div>
                </div>
              ) : (
                <LyricsView
                  lyrics={lyrics}
                  plainLyrics={plainLyrics}
                  currentTime={currentTime}
                  isVisible={true}
                />
              )}
            </div>

            {/* Lyric Metro watermark */}
            <div className="absolute bottom-4 right-5 text-white/10 text-xs font-medium select-none">
              lrclib.net
            </div>

            {/* Background blur decoration */}
            <div
              className="absolute inset-0 pointer-events-none"
              style={{
                background: `radial-gradient(ellipse 60% 50% at 100% 50%, ${bgColor}33 0%, transparent 70%)`,
              }}
            />
          </section>
        )}

        {/* === MOBILE: Songs view === */}
        {mobileView === "songs" && (
          <div className="flex-1 overflow-hidden md:hidden">
            <SongList
              songs={SONGS}
              currentSong={currentSong}
              isPlaying={isPlaying}
              onSelect={handleSongSelect}
            />
          </div>
        )}
      </div>

      {/* Mobile mini-player (shown when not in player view) */}
      {mobileView !== "player" && (
        <div
          className="md:hidden flex-shrink-0 border-t border-white/10 cursor-pointer"
          style={{ background: "rgba(15,15,25,0.95)" }}
          onClick={() => setMobileView("player")}
        >
          <div className="flex items-center gap-3 px-4 py-3">
            <img
              src={thumbnailUrl}
              alt={currentSong.title}
              className="w-11 h-11 rounded-xl object-cover flex-shrink-0 shadow"
            />
            <div className="flex-1 min-w-0">
              <p className="text-white text-sm font-semibold truncate leading-tight">
                {currentSong.title}
              </p>
              <p className="text-white/45 text-xs truncate mt-0.5">{currentSong.artist}</p>
            </div>
            {/* Mini progress */}
            <div className="flex items-center gap-3">
              <div className="w-16 h-1 bg-white/15 rounded-full overflow-hidden">
                <div
                  className="h-full bg-white/60 rounded-full"
                  style={{
                    width: `${duration > 0 ? (currentTime / duration) * 100 : 0}%`,
                  }}
                />
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handlePlayPause();
                }}
                className="w-9 h-9 bg-white rounded-full flex items-center justify-center flex-shrink-0 shadow"
              >
                {isPlaying ? (
                  <svg viewBox="0 0 24 24" fill="black" className="w-5 h-5">
                    <path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/>
                  </svg>
                ) : (
                  <svg viewBox="0 0 24 24" fill="black" className="w-5 h-5">
                    <path d="M8 5v14l11-7z"/>
                  </svg>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      <style>{`
        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }

        @keyframes soundbar {
          0%, 100% { transform: scaleY(0.4); opacity: 0.6; }
          50% { transform: scaleY(1); opacity: 1; }
        }

        @keyframes bounce {
          0%, 100% { height: 4px; }
          50% { height: 12px; }
        }
      `}</style>
    </div>
  );
}
